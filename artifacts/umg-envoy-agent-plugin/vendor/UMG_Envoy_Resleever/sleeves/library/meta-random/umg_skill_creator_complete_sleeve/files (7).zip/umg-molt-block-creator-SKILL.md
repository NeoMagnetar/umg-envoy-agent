---
name: umg-molt-block-creator
description: Create properly formatted UMG MOLT blocks (TRG, DIR, INST, SUBJ, PRIM, PHIL, BP, CON, VER). Use this skill when user wants to create any MOLT block type, needs to capture behavior as a modular block, or says things like 'create a trigger', 'I need a directive', 'make a MOLT block', or 'generate a block'. Make sure to use even if user doesn't explicitly say 'MOLT' or 'UMG' - any request to create modular cognitive units, capture behaviors, define reusable components, or structure cognitive instructions should trigger this skill. Examples include: 'how do I capture this as a block', 'create a reusable component', 'define this behavior', 'structure this instruction', or 'make this modular'.
---

# UMG MOLT Block Creator

Generate properly formatted MOLT blocks following Universal Modular Generation (UMG) conventions.

## Overview

MOLT blocks are atomic units of cognitive specification in UMG. This skill helps you create any block type with correct formatting, naming conventions, required fields, and proper structure. Each block represents a modular, composable unit of meaning that can be combined with others to build complex cognitive architectures.

## Block Types Reference

**TRIGGER (TRG)** - Activation conditions ("when to engage")
- Purpose: Detect user intent, match contexts, determine when capabilities should activate
- Content pattern: "Activate when...", "Trigger if...", "Detect..."
- Example uses: User request detection, context matching, capability routing

**DIRECTIVE (DIR)** - Goals to achieve ("what outcome")
- Purpose: Define objectives, success criteria, desired end states
- Content pattern: "GOAL: Achieve X", "Objective: Complete Y"
- Example uses: Project goals, task objectives, success definitions

**INSTRUCTION (INST)** - Execution steps ("how to do it")
- Purpose: Provide workflows, procedures, step-by-step processes
- Content pattern: "STEPS:\n1. First\n2. Second\n3. Third"
- Example uses: Workflows, procedures, algorithms, processes

**SUBJECT (SUBJ)** - Domain knowledge ("what to operate on")
- Purpose: Define areas of expertise, data types, knowledge domains
- Content pattern: "You understand...", "You work with..."
- Example uses: Domain expertise, knowledge areas, capabilities

**PRIMARY (PRIM)** - Core values ("why/principles")
- Purpose: Set non-negotiable rules, safety constraints, foundational values
- Content pattern: "CORE VALUE:", "ABSOLUTE RULE:", "NON-NEGOTIABLE:"
- Example uses: Safety rules, ethical guidelines, fundamental principles

**PHILOSOPHY (PHIL)** - Reasoning approaches ("how to think")
- Purpose: Define problem-solving strategies, mental models, thinking patterns
- Content pattern: "APPROACH:", "Think about...", "Consider..."
- Example uses: Reasoning strategies, decision frameworks, mental models

**BLUEPRINT (BP)** - Output templates ("what to produce")
- Purpose: Provide standardized formats, document structures, templates
- Content pattern: Template text with placeholders
- Example uses: Document templates, output formats, standard structures

**CONSTRAINT (CON)** - Boundaries and limits
- Purpose: Set safety limits, operational boundaries, restrictions
- Content pattern: "CONSTRAINT:", "LIMIT:", "BOUNDARY:"
- Example uses: Safety boundaries, operational limits, restrictions

**VERIFICATION (VER)** - Quality checks
- Purpose: Define validation rules, acceptance criteria, quality checks
- Content pattern: "VERIFICATION:", "CHECK:", "VALIDATE:"
- Example uses: Quality assurance, validation rules, acceptance tests

## Block Creation Workflow

### Step 1: Identify Block Type

Ask the decision questions:
- Describing **when** something activates? → **TRIGGER**
- Defining **what goal** to achieve? → **DIRECTIVE**
- Writing **steps** to follow? → **INSTRUCTION**
- Explaining **domain knowledge**? → **SUBJECT**
- Setting a **core value** or rule? → **PRIMARY**
- Describing **how to think**? → **PHILOSOPHY**
- Providing a **template**? → **BLUEPRINT**
- Setting a **limit** or boundary? → **CONSTRAINT**
- Defining a **quality check**? → **VERIFICATION**

### Step 2: Generate Block ID

**Format:** `TYPE.DOMAIN.NUMBER`

**Components:**
- **TYPE:** Three-letter block type code (TRG, DIR, INST, etc.)
- **DOMAIN:** 2-4 letter domain abbreviation (WEB, FILE, DOC, etc.)
- **NUMBER:** Three digits, zero-padded (001, 002, 010, 100)

**Examples:**
- `TRG.WEB.001` - First web-related trigger
- `DIR.DOC.003` - Third documentation directive  
- `INST.FILE.012` - Twelfth file operation instruction
- `PRIM.CORE.001` - First core primary value
- `PHIL.REASON.002` - Second reasoning philosophy

**Common Domains:**
- WEB (web operations)
- FILE (file system)
- DOC (documentation)
- CODE (coding)
- DATA (data processing)
- GIT (version control)
- ENV (environment)
- META (self-modification)
- CORE (fundamental/cross-cutting)

### Step 3: Write Clear Name

**Guidelines:**
- Be specific and descriptive
- Explain purpose in 2-5 words
- Use title case
- Avoid jargon unless domain-specific

**Good examples:**
- "Web Search Request"
- "Read File Workflow"
- "Honesty Over Helpfulness"
- "First Principles Thinking"

**Bad examples:**
- "Thing" (too vague)
- "Do stuff with files" (not specific)
- "Process" (ambiguous)

### Step 4: Write Description

**Purpose:** Brief one-sentence explanation of what this block is for

**Pattern:** "When/What this [verb]"

**Examples:**
- TRIGGER: "Activates when user needs current information"
- DIRECTIVE: "Ensures files are organized logically"
- INSTRUCTION: "Steps for reading files safely"
- PRIMARY: "Core safety principle governing all actions"

### Step 5: Write Content

**Content varies by type:**

**TRIGGER content:**
```
Activate when [specific conditions].
Keywords: [trigger words/phrases].
Context: [when this matters].
```

**DIRECTIVE content:**
```
GOAL: [Desired outcome].
Success means: [What success looks like].
Prioritize: [What matters most].
```

**INSTRUCTION content:**
```
STEPS:
1. [First action with specifics]
2. [Second action with specifics]
3. [Third action with specifics]
[etc.]
```

**SUBJECT content:**
```
You understand [domain/topic].
You work with [specific things].
You know [key concepts].
```

**PRIMARY content:**
```
CORE VALUE: [Principle name]

[Explanation of why this matters]
[How to apply it]
[What this means in practice]
```

**PHILOSOPHY content:**
```
APPROACH: [Thinking method name]

[How to apply this thinking]
[When to use it]
[What it enables]
```

**BLUEPRINT content:**
```
[Actual template with clear structure]
[Use placeholders like [X] or {variable}]
[Show expected format]
```

### Step 6: Identify Compositions

**Composition patterns:**
- **Triggers** compose with **Directives** and **Instructions**
  - "When X happens, pursue goal Y using steps Z"
- **Directives** compose with **Instructions**
  - "To achieve goal X, follow these steps"
- **Instructions** reference **Subjects** and **Blueprints**
  - "When doing X, use knowledge from Y, output format Z"
- **Primary** governs **all other blocks**
  - Core values constrain all behaviors

**Ask yourself:**
- What block would naturally follow this one?
- What provides the goal for this instruction?
- What knowledge does this instruction need?
- What constrains this behavior?

### Step 7: Add Metadata

```json
"metadata": {
  "domain": "domain-name",
  "priority": 10,
  "version": "1.0.0"
}
```

**Priority guidelines:**
- 1000+ : Core safety/governance (PRIMARY)
- 100-999: Important capabilities (DIRECTIVE, major INSTRUCTION)
- 10-99  : Standard blocks (most blocks)
- 1-9    : Optional/convenience blocks

## Standard JSON Format

```json
{
  "id": "TYPE.DOMAIN.001",
  "type": "TYPE",
  "name": "Clear Descriptive Name",
  "description": "Brief one-sentence purpose",
  "content": "Actual trigger condition, goal statement, or instructions",
  "composes_with": ["OTHER.BLOCK.001", "ANOTHER.BLOCK.002"],
  "metadata": {
    "domain": "domain-name",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

## Complete Examples

### Example 1: Trigger Block

```json
{
  "id": "TRG.WEB.001",
  "type": "TRIGGER",
  "name": "Web Search Request",
  "description": "Activates when user needs current information from the web",
  "content": "Activate when user asks for current information, recent events, breaking news, or explicitly requests web search. Keywords: 'search', 'latest', 'current', 'recent', 'what's happening', 'news', 'find information about'. Also activate when knowledge cutoff is mentioned or information seems time-sensitive.",
  "composes_with": ["DIR.WEB.001", "INST.WEB.001"],
  "metadata": {
    "domain": "web",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

### Example 2: Directive Block

```json
{
  "id": "DIR.FILE.001",
  "type": "DIRECTIVE",
  "name": "Organize Files Logically",
  "description": "Ensures files are structured in intuitive, maintainable way",
  "content": "GOAL: Files organized in clear directory structure that makes sense for the project type. Success means: someone new can find files easily, related files grouped together, standard conventions followed. Prioritize: clarity over cleverness, convention over custom.",
  "composes_with": ["INST.FILE.003", "PHIL.ORG.001"],
  "metadata": {
    "domain": "file-operations",
    "priority": 50,
    "version": "1.0.0"
  }
}
```

### Example 3: Instruction Block

```json
{
  "id": "INST.FILE.001",
  "type": "INSTRUCTION",
  "name": "Safe File Read Workflow",
  "description": "Step-by-step process for reading files safely",
  "content": "STEPS:\n1. Validate file path format\n2. Check file exists (report error if not)\n3. Verify read permissions\n4. Determine file type/encoding\n5. Read file contents\n6. Parse format (JSON, CSV, plain text, etc.)\n7. Return structured data\n8. Handle errors gracefully (report what went wrong)\n\nNever assume file format - always detect and verify.",
  "composes_with": ["TRG.FILE.001", "SUBJ.FILE.001"],
  "metadata": {
    "domain": "file-operations",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

### Example 4: Subject Block

```json
{
  "id": "SUBJ.FILE.001",
  "type": "SUBJECT",
  "name": "File System Operations",
  "description": "Knowledge about file systems, paths, and operations",
  "content": "You understand file systems: directories, files, paths, permissions. You know common file types and formats. You understand hierarchical directory structures, absolute vs relative paths, and file operations (read, write, move, delete). You're familiar with: JSON, CSV, Markdown, plain text, and binary files.",
  "metadata": {
    "domain": "file-operations",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

### Example 5: Primary Value Block

```json
{
  "id": "PRIM.SAFE.001",
  "type": "PRIMARY",
  "name": "Safety First",
  "description": "Core principle: prevent harm above all else",
  "content": "ABSOLUTE RULE: Safety is non-negotiable. Before any action that could cause harm, data loss, or irreversible change:\n\n1. Assess risk honestly\n2. Explain what will happen\n3. Show what could be lost\n4. Get explicit user approval\n5. Proceed only after clear YES\n\nIf uncertain about safety: ASK, don't assume.\nIf potentially dangerous: STOP and get permission.\n\nPrevent harm > Complete task quickly.\n\nThis overrides all other directives.",
  "metadata": {
    "domain": "core",
    "priority": 1000,
    "version": "1.0.0"
  }
}
```

### Example 6: Philosophy Block

```json
{
  "id": "PHIL.REASON.001",
  "type": "PHILOSOPHY",
  "name": "First Principles Thinking",
  "description": "Break problems down to fundamental truths",
  "content": "APPROACH: When facing complex problems, decompose to fundamental truths and build up from there.\n\n1. Identify assumptions in the current approach\n2. Question each assumption: Is this actually true?\n3. Break down to fundamental facts that are undeniably true\n4. Rebuild solution from these foundations\n5. Often reveals simpler or novel approaches\n\nUse when: Complex problems, need innovation, challenging conventional wisdom.\n\nThis enables: Fresh perspectives, simpler solutions, breakthrough thinking.",
  "metadata": {
    "domain": "reasoning",
    "priority": 50,
    "version": "1.0.0"
  }
}
```

### Example 7: Blueprint Block

```json
{
  "id": "BP.DOC.001",
  "type": "BLUEPRINT",
  "name": "README Template",
  "description": "Standard format for project README files",
  "content": "# [Project Name]\n\n[One-sentence description]\n\n## Installation\n\n```bash\n[Installation command]\n```\n\n## Usage\n\n```\n[Basic usage example]\n```\n\n## Features\n\n- [Feature 1]\n- [Feature 2]\n- [Feature 3]\n\n## Documentation\n\n[Link to detailed docs]\n\n## Contributing\n\n[How to contribute]\n\n## License\n\n[License information]",
  "metadata": {
    "domain": "documentation",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

## Best Practices

### DO:
✓ **Be specific and concrete** - Vague blocks don't help
✓ **Make instructions actionable** - Someone should be able to follow them
✓ **Use consistent formatting** - Follow the examples above exactly
✓ **Name blocks clearly** - Name should explain purpose immediately
✓ **Compose thoughtfully** - Link blocks that work together
✓ **Version everything** - Track changes with metadata
✓ **Test your blocks** - Try using them, see if they work

### DON'T:
✗ **Be ambiguous** - "Do something appropriate" is useless
✗ **Overcomplicate** - Simpler is almost always better
✗ **Duplicate** - Check if similar block exists first
✗ **Use jargon unnecessarily** - Be accessible
✗ **Skip metadata** - Domain and version matter
✗ **Forget compositions** - Blocks are meant to work together

## Validation Checklist

Before finalizing a block, verify:

- [ ] ID follows TYPE.DOMAIN.NUMBER format
- [ ] Type matches one of the 9 standard types
- [ ] Name is clear and specific (2-5 words)
- [ ] Description is one sentence explaining purpose
- [ ] Content is actionable and clear
- [ ] Content format matches block type (steps for INST, conditions for TRG, etc.)
- [ ] composes_with suggests logical partnerships
- [ ] Metadata includes domain and version
- [ ] JSON syntax is valid
- [ ] Block would actually be useful

## When to Create New Blocks

**Create a TRIGGER when:**
- You identify a new activation pattern
- Users request capability in consistent ways
- Context needs to trigger specific behavior

**Create a DIRECTIVE when:**
- You define a new goal or objective
- Success criteria need to be explicit
- Outcome needs to be specified

**Create an INSTRUCTION when:**
- You document a repeatable process
- Steps need to be standardized
- Workflow needs to be captured

**Create a SUBJECT when:**
- You introduce new domain knowledge
- Expertise needs to be defined
- Knowledge area needs specification

**Create a PRIMARY when:**
- You establish a non-negotiable rule
- Safety needs to be enforced
- Core value needs to be explicit

**Create a PHILOSOPHY when:**
- You define a thinking pattern
- Reasoning approach needs capture
- Problem-solving method should be reused

**Create a BLUEPRINT when:**
- You standardize an output format
- Template would prevent errors
- Consistency matters

**Create a CONSTRAINT when:**
- You set a boundary or limit
- Safety requires restriction
- Operation needs bounds

**Create a VERIFICATION when:**
- You define a quality check
- Validation needs to be consistent
- Acceptance criteria should be explicit

## Output Format for This Skill

When creating a block, output it as properly formatted JSON that can be immediately used:

```json
{
  "id": "TYPE.DOMAIN.001",
  "type": "TYPE",
  "name": "Block Name",
  "description": "What this block does",
  "content": "Block-type-specific content",
  "composes_with": ["RELATED.BLOCK.001"],
  "metadata": {
    "domain": "domain-name",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

Make sure JSON is valid and ready to use immediately.
