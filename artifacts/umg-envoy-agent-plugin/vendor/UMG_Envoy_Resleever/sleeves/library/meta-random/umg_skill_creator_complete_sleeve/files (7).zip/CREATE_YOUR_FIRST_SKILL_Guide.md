# CREATE YOUR FIRST SKILL - Practical Guide

**Using UMG.ENVOY.SKILL_CREATOR to build skills for Claude Skill Hub**

---

## 🎯 WHAT WE'RE DOING

**Goal:** Create a real skill for Claude Skill Hub

**Method:** Use UMG blocks as your workflow guide

**Output:** A working SKILL.md file ready to use

---

## 📋 QUICK START (30 Minutes)

### EXAMPLE: Create "UMG MOLT Block Creator" Skill

Let's create a skill that helps generate UMG MOLT blocks. This demonstrates UMG being used to create tools for UMG itself (meta!).

---

## STEP 1: INTENT INTERVIEW (Using INST.SC.001)

### Questions to Answer:

**1. What should this skill enable?**
```
Generate properly formatted UMG MOLT blocks
- Support all types: TRG, DIR, INST, SUBJ, PRIM, PHIL, BP
- Include all required fields (id, type, name, description, content)
- Follow UMG naming conventions
- Suggest composes_with relationships
```

**2. When should it trigger?**
```
User says:
- "Create a MOLT block"
- "I need a trigger block"
- "Generate a directive"
- "Make a MOLT block for X"
- Describes behavior to capture as modular block
```

**3. Expected output format?**
```
JSON formatted MOLT block with:
- Proper ID (TRG.XXX.001 format)
- Type field
- Clear name and description
- Actionable content
- Metadata (domain, version)
```

**4. Need test cases?**
```
YES - Can verify:
- JSON syntax valid
- Required fields present
- ID follows convention
- Content is actionable
```

**Intent confirmed!** ✓

---

## STEP 2: WRITE SKILL.MD (Using INST.SC.003-005)

### Part A: YAML Frontmatter (INST.SC.003)

```yaml
---
name: umg-molt-block-creator
description: Create properly formatted UMG MOLT blocks (TRG, DIR, INST, SUBJ, PRIM, PHIL, BP, CON, VER). Use this skill when user wants to create any MOLT block type, needs to capture behavior as a modular block, or says things like 'create a trigger', 'I need a directive', 'make a MOLT block', or 'generate a block'. Make sure to use even if user doesn't explicitly say 'MOLT' or 'UMG' - any request to create modular cognitive units, capture behaviors, or define reusable components should trigger this skill. Examples: 'how do I capture this as a block', 'create a reusable component', 'define this behavior'.
---
```

**Note the pushy description!** (PRIM.SC.002)

### Part B: Skill Body (INST.SC.005)

```markdown
# UMG MOLT Block Creator

Generate properly formatted MOLT blocks following UMG conventions.

## Overview

MOLT blocks are atomic units of cognitive specification in UMG. This skill helps you create any block type with correct formatting, naming, and structure.

## Block Types

**TRIGGER (TRG)** - Activation conditions ("when to engage")
- Use for: Detecting user intent, context matching

**DIRECTIVE (DIR)** - Goals to achieve ("what outcome")
- Use for: Defining objectives, success criteria

**INSTRUCTION (INST)** - Execution steps ("how to do it")
- Use for: Workflows, procedures, step-by-step processes

**SUBJECT (SUBJ)** - Domain knowledge ("what to operate on")
- Use for: Defining areas of expertise, data types

**PRIMARY (PRIM)** - Core values ("why/principles")
- Use for: Non-negotiable rules, safety constraints

**PHILOSOPHY (PHIL)** - Reasoning approaches ("how to think")
- Use for: Problem-solving strategies, mental models

**BLUEPRINT (BP)** - Output templates ("what to produce")
- Use for: Standardized formats, document structures

**CONSTRAINT (CON)** - Boundaries and limits
- Use for: Safety limits, operational constraints

**VERIFICATION (VER)** - Quality checks
- Use for: Validation rules, acceptance criteria

## Creating a Block

### 1. Identify Block Type

Ask yourself:
- Describing when something activates? → TRIGGER
- Defining a goal? → DIRECTIVE
- Writing steps to follow? → INSTRUCTION
- Explaining domain knowledge? → SUBJECT
- Setting a core value? → PRIMARY
- Describing how to think? → PHILOSOPHY
- Providing a template? → BLUEPRINT
- Setting a limit? → CONSTRAINT
- Defining a check? → VERIFICATION

### 2. Generate Block ID

Format: `TYPE.DOMAIN.NUMBER`

Examples:
- `TRG.WEB.001` - First web-related trigger
- `DIR.DOC.003` - Third documentation directive
- `INST.FILE.012` - Twelfth file operation instruction

Rules:
- Type: Three-letter code (TRG, DIR, etc.)
- Domain: 2-4 letter abbreviation
- Number: Three digits, zero-padded

### 3. Write Block Content

**For TRIGGERS:**
```
Content should describe WHEN to activate.
Use: "Activate when...", "Trigger if...", "Detect..."
Be specific about conditions.
```

**For DIRECTIVES:**
```
Content should describe GOAL.
Use: "GOAL: Achieve X", "Objective: Complete Y"
Focus on outcomes, not steps.
```

**For INSTRUCTIONS:**
```
Content should list STEPS.
Use numbered lists: "STEPS:\n1. First action\n2. Second action"
Be actionable and clear.
```

### 4. Add Metadata

```json
"metadata": {
  "domain": "domain-name",
  "priority": 10,
  "version": "1.0.0"
}
```

### 5. Suggest Compositions

Think: What blocks would work with this?
- Triggers compose with Directives and Instructions
- Directives compose with Instructions
- Instructions reference Subjects and Blueprints

## Output Format

```json
{
  "id": "TYPE.DOMAIN.001",
  "type": "TYPE",
  "name": "Clear Descriptive Name",
  "description": "Brief explanation of purpose",
  "content": "Actual trigger condition, goal statement, or step-by-step instructions",
  "composes_with": ["OTHER.BLOCK.001", "OTHER.BLOCK.002"],
  "metadata": {
    "domain": "domain-name",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

## Examples

### Example 1: Trigger Block

```json
{
  "id": "TRG.WEB.001",
  "type": "TRIGGER",
  "name": "Web Search Request",
  "description": "Activates when user needs current information",
  "content": "Activate when user asks for current information, recent events, or explicitly requests web search. Keywords: 'search', 'latest', 'current', 'recent', 'what's happening'.",
  "composes_with": ["DIR.WEB.001", "INST.WEB.001"],
  "metadata": {
    "domain": "web",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

### Example 2: Instruction Block

```json
{
  "id": "INST.FILE.001",
  "type": "INSTRUCTION",
  "name": "Read File Workflow",
  "description": "Steps for reading files safely",
  "content": "STEPS:\n1. Check file path is valid\n2. Verify file exists\n3. Check permissions\n4. Read file contents\n5. Parse format (JSON, CSV, etc.)\n6. Return structured data\n7. Report errors if any",
  "composes_with": ["TRG.FILE.001", "SUBJ.FILE.001"],
  "metadata": {
    "domain": "file-operations",
    "priority": 10,
    "version": "1.0.0"
  }
}
```

### Example 3: Primary Value Block

```json
{
  "id": "PRIM.SAFE.001",
  "type": "PRIMARY",
  "name": "Safety First",
  "description": "Core safety principle",
  "content": "ABSOLUTE RULE: Safety is non-negotiable. Before any action that could cause harm, data loss, or irreversible change:\n1. Assess risk\n2. Explain what will happen\n3. Get explicit approval\n4. Proceed only after YES\n\nPrevent harm > Complete task quickly",
  "metadata": {
    "domain": "core",
    "priority": 1000,
    "version": "1.0.0"
  }
}
```

## Best Practices

✓ **Be Specific:** Vague blocks don't help
✓ **Be Actionable:** Instructions should be followable
✓ **Use Consistent Format:** Follow examples above
✓ **Name Clearly:** Name should explain purpose
✓ **Compose Smartly:** Link related blocks
✓ **Version Everything:** Track changes with metadata

✗ **Avoid Ambiguity:** "Do something appropriate" is useless
✗ **Don't Overcomplicate:** Simple is better
✗ **Don't Duplicate:** Check if block already exists
```

---

## STEP 3: VALIDATE (Using VER.SC.001)

### Checklist:

```
✓ YAML frontmatter present
✓ Name is lowercase-hyphenated
✓ Description is pushy with trigger phrases
✓ Body under 500 lines (or uses references/)
✓ Examples included
✓ Instructions are clear
✓ Markdown valid
```

**All checks pass!** ✓

---

## STEP 4: CREATE TEST CASES (Using INST.SC.006)

### Test Prompts:

**Should trigger:**
1. "Create a trigger block for detecting web searches"
2. "I need an instruction block for file reading"
3. "Generate a MOLT block that captures this behavior"

**Should produce:**
- Valid JSON
- Correct block type
- All required fields
- Actionable content

**Should NOT trigger:**
1. "Create a web application"
2. "Write some code for me"
3. "Make a document"

---

## STEP 5: PACKAGE (Using INST.SC.011)

### Directory Structure:

```
umg-molt-block-creator/
├── SKILL.md (the file we created)
├── README.md (optional usage guide)
└── examples/ (optional)
    ├── trigger-examples.json
    ├── directive-examples.json
    └── instruction-examples.json
```

---

## 📦 FINAL OUTPUT

**File:** `umg-molt-block-creator/SKILL.md`

**Ready to:**
- Add to Claude Skill Hub
- Use in your projects
- Share with others

**What it does:**
- Generates proper MOLT blocks
- Follows UMG conventions
- Provides clear examples
- Triggers when needed

---

## 🎯 CREATE YOUR OWN SKILL (Template)

### Use this workflow:

**1. Intent Interview** (INST.SC.001)
```
□ What should skill do?
□ When should it trigger?
□ What output format?
□ Need test cases?
```

**2. Write YAML** (INST.SC.003-004)
```yaml
---
name: skill-name
description: [What it does]. Use when [contexts]. Make sure to use even if [undertrigger prevention].
---
```

**3. Write Body** (INST.SC.005)
```markdown
# Skill Name

[Overview]

## How to Use
[Instructions]

## Examples
[Concrete examples]
```

**4. Validate** (VER.SC.001)
```
□ Format correct
□ Description pushy
□ Examples clear
```

**5. Test** (INST.SC.006-008)
```
□ Create test prompts
□ Verify triggering
□ Check outputs
```

**6. Package** (INST.SC.011)
```
skill-name/
├── SKILL.md
└── (optional resources)
```

---

## 💡 SKILL IDEAS TO BUILD

**Using UMG principles:**

1. **UMG Sleeve Builder**
   - Generates complete sleeve specs
   - Composes NeoStacks and NeoBlocks
   - Creates MOLT block libraries

2. **NeoBlock Composer**
   - Takes multiple MOLT blocks
   - Combines into NeoBlocks
   - Suggests compositions

3. **Governance Validator**
   - Checks sleeve against Tool Anchor Ethos
   - Validates Primary values enforced
   - Reports governance gaps

4. **UMG to OpenClaw Adapter**
   - Converts UMG specs to OpenClaw configs
   - Handles model routing
   - Includes governance

5. **Skill Quality Analyzer**
   - Reviews existing skills
   - Suggests improvements
   - Optimizes descriptions

---

## ✅ SUCCESS CHECKLIST

**You've successfully created a skill when:**

- ✓ YAML frontmatter valid
- ✓ Description triggers appropriately
- ✓ Instructions are clear
- ✓ Examples help understanding
- ✓ Test cases pass
- ✓ Properly packaged
- ✓ Ready to deploy

---

## 🚀 NEXT STEPS

**1. Create your first skill:**
```
Pick something you do repeatedly
Capture it as a skill
Follow this guide
Deploy it
```

**2. Use UMG Skill Creator sleeve:**
```
Load the sleeve spec
Let it guide you through creation
Leverage MOLT blocks as workflow
```

**3. Share your skills:**
```
Contribute to Skill Hub
Help others
Build the ecosystem
```

---

**You now have:**
- ✅ Complete UMG Skill Creator sleeve (32 MOLT blocks)
- ✅ Working example (MOLT Block Creator skill)
- ✅ Template for creating more skills
- ✅ Workflow using UMG principles

**Start creating!** 🎯
