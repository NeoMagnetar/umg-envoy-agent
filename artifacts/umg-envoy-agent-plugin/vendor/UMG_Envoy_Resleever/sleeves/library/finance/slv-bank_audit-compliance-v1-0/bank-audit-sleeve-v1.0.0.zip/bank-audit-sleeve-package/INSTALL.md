# QUICK INSTALLATION GUIDE
## Bank Account Compliance Auditor Sleeve v1.0.0

**5-Minute Setup**

---

## STEP 1: Extract Package

Extract this zip file to a working directory:
```
C:\openclaw-sleeves\bank-audit\
```

---

## STEP 2: Install Prerequisites

**Required:**
- OpenClaw 0.4.0+ (or any AI agent supporting system prompts)
- OpenAI API key (get from https://platform.openai.com)

**Check if you have OpenClaw:**
```powershell
openclaw --version
```

If not installed, visit OpenClaw documentation for installation.

---

## STEP 3: Configure

**Option A - Use with OpenClaw:**

1. Copy system prompt:
```powershell
Copy-Item system-prompt.txt $env:USERPROFILE\.openclaw\prompts\bank-auditor.txt
```

2. Copy config and add your API key:
```powershell
Copy-Item openclaw-config.json $env:USERPROFILE\.openclaw\bank-auditor-config.json
notepad $env:USERPROFILE\.openclaw\bank-auditor-config.json
# Edit line: "api_key": "sk-YOUR-KEY-HERE"
```

3. Start OpenClaw:
```powershell
openclaw --config bank-auditor-config.json
```

**Option B - Use with Any AI Agent:**

1. Open `system-prompt.txt`
2. Copy entire contents
3. Paste into your AI agent's system prompt field
4. Start chatting

---

## STEP 4: Test

Try this:

```
USER: What audit capabilities do you have?

AGENT: [Should describe 7 NeoStacks and compliance audit functions]
```

Then try a sample audit:

```
USER: Audit this account:
- Account #: TEST123
- Type: Business Checking
- Opened: 2024-01-15
- Customer: ABC Corp LLC
```

---

## DOCUMENTATION

- **README.html** - Package overview (open in browser)
- **SLEEVE_SPECIFICATION.html** - Complete technical spec
- **OPENCLAW_DEPLOYMENT.html** - Detailed deployment guide
- **quick-reference.html** - Daily use cheat sheet
- **compliance-checklists.html** - Audit checklists

All files also available as Markdown (.md) for editing.

---

## TROUBLESHOOTING

**Problem:** Agent doesn't mention audit capabilities
**Solution:** Verify system-prompt.txt loaded correctly

**Problem:** "Insufficient tokens" error
**Solution:** Increase max_tokens in config to 16384

**Problem:** Files not attaching
**Solution:** Enable file_read tool in config

**Full troubleshooting:** See OPENCLAW_DEPLOYMENT.html

---

## SUPPORT

**Documentation:**
- Full spec: SLEEVE_SPECIFICATION.html
- Deployment: OPENCLAW_DEPLOYMENT.html
- Quick ref: quick-reference.html

**Ready to audit!**

Start with: `openclaw --config bank-auditor-config.json`

---

**Package Version:** 1.0.0  
**Release Date:** 2026-03-20  
**Framework:** UMG (Universal Modular Generation)
