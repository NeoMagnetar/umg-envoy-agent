# COMPLETE MOLT BLOCKS LIBRARY
## Bank Account Compliance Auditor - SLV.BANK_AUDIT.COMPLIANCE.v1.0

**Total Blocks:** 147  
**Block Types:** TRG(24), DIR(18), INST(42), SUBJ(21), PRIM(8), PHIL(6), BP(18), VER(10)

---

## BLOCK TYPE REFERENCE

| Type | Code | Purpose | Count |
|------|------|---------|-------|
| TRIGGER | TRG | Activation conditions ("when to engage") | 24 |
| DIRECTIVE | DIR | Goals to achieve ("what outcome") | 18 |
| INSTRUCTION | INST | Execution steps ("how to do it") | 42 |
| SUBJECT | SUBJ | Domain knowledge ("what to operate on") | 21 |
| PRIMARY | PRIM | Core values ("why/principles") | 8 |
| PHILOSOPHY | PHIL | Reasoning approaches ("how to think") | 6 |
| BLUEPRINT | BP | Output templates ("what to produce") | 18 |
| VERIFICATION | VER | Quality checks ("how to validate") | 10 |

---

# PART 1: TRIGGERS (TRG) - 24 BLOCKS

**Purpose:** Triggers define activation conditions - when specific audit capabilities should engage.

---

## TRG.AUDIT.001 - New Account Audit Requested

```json
{
  "id": "TRG.AUDIT.001",
  "type": "TRIGGER",
  "name": "New Account Audit Requested",
  "description": "Activates when user requests audit of newly opened account",
  "content": "Activate when user says: 'audit this new account', 'review new account opening', 'check this account for compliance', 'new account quality assurance', or provides account opening data for review. Also activate if user mentions 'KYC verification', 'account setup check', or 'opening documentation review'.",
  "composes_with": ["DIR.AUDIT.001", "INST.ACCT.001"],
  "metadata": {
    "domain": "account-verification",
    "priority": 100,
    "version": "1.0.0",
    "regulatory_basis": "BSA/AML - Customer Identification Program"
  }
}
```

---

## TRG.AUDIT.002 - Transaction Review Triggered

```json
{
  "id": "TRG.AUDIT.002",
  "type": "TRIGGER",
  "name": "Transaction Review Triggered",
  "description": "Activates when transaction data provided for analysis",
  "content": "Activate when user provides transaction list, transaction file, or requests transaction analysis. Keywords: 'review these transactions', 'analyze transaction patterns', 'check for suspicious activity', 'transaction monitoring', 'look at these transfers'. Also activate for batch transaction data, wire transfer lists, or cash transaction reports.",
  "composes_with": ["DIR.AUDIT.002", "INST.TXN.001"],
  "metadata": {
    "domain": "transaction-analysis",
    "priority": 100,
    "version": "1.0.0",
    "regulatory_basis": "BSA - Currency Transaction Reporting"
  }
}
```

---

## TRG.AUDIT.003 - CTR Filing Verification

```json
{
  "id": "TRG.AUDIT.003",
  "type": "TRIGGER",
  "name": "CTR Filing Verification",
  "description": "Activates when Currency Transaction Report compliance needs verification",
  "content": "Activate when user asks: 'verify CTR filing', 'check if CTR was filed', 'CTR compliance review', 'transactions over $10,000', 'cash transactions requiring reporting'. Activate for any mention of large cash transactions, currency reporting requirements, or CTR exemption validation.",
  "composes_with": ["DIR.AUDIT.003", "INST.CTR.001"],
  "metadata": {
    "domain": "compliance-verification",
    "priority": 95,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1020.310 - Currency Transaction Reporting"
  }
}
```

---

## TRG.AUDIT.004 - SAR Decision Analysis

```json
{
  "id": "TRG.AUDIT.004",
  "type": "TRIGGER",
  "name": "SAR Decision Analysis",
  "description": "Activates when Suspicious Activity Report decision needs review",
  "content": "Activate when user asks: 'should we file a SAR', 'suspicious activity review', 'SAR decision documentation', 'is this reportable activity', 'evaluate for suspicious activity reporting'. Keywords: 'SAR', 'suspicious', 'unusual activity', 'money laundering indicators', 'structuring', 'red flags'.",
  "composes_with": ["DIR.AUDIT.004", "INST.SAR.001"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 98,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1020.320 - Suspicious Activity Reporting"
  }
}
```

---

## TRG.AUDIT.005 - OFAC Screening Verification

```json
{
  "id": "TRG.AUDIT.005",
  "type": "TRIGGER",
  "name": "OFAC Screening Verification",
  "description": "Activates when sanctions screening compliance needs verification",
  "content": "Activate when user mentions: 'OFAC check', 'sanctions screening', 'SDN list', 'verify against sanctions', 'blocked persons check', 'sanctioned countries'. Also for customer names requiring screening, wire transfer parties, or periodic rescreening verification.",
  "composes_with": ["DIR.AUDIT.005", "INST.OFAC.001"],
  "metadata": {
    "domain": "sanctions-compliance",
    "priority": 99,
    "version": "1.0.0",
    "regulatory_basis": "OFAC - Specially Designated Nationals List"
  }
}
```

---

## TRG.AUDIT.006 - Beneficial Ownership Verification

```json
{
  "id": "TRG.AUDIT.006",
  "type": "TRIGGER",
  "name": "Beneficial Ownership Verification",
  "description": "Activates when beneficial ownership documentation needs review",
  "content": "Activate for: 'beneficial owner verification', 'FinCEN form check', 'legal entity customer', 'who owns this company', 'UBO verification' (Ultimate Beneficial Owner), 'corporate ownership structure'. Required for all legal entity accounts - corporations, LLCs, partnerships, trusts.",
  "composes_with": ["DIR.AUDIT.006", "INST.BEN.001"],
  "metadata": {
    "domain": "customer-due-diligence",
    "priority": 94,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1010.230 - Beneficial Ownership Requirements"
  }
}
```

---

## TRG.AUDIT.007 - Structuring Pattern Detection

```json
{
  "id": "TRG.AUDIT.007",
  "type": "TRIGGER",
  "name": "Structuring Pattern Detection",
  "description": "Activates when transaction patterns suggest potential structuring",
  "content": "Activate when analyzing: multiple transactions just under $10,000, split deposits same day, frequent cash activity avoiding reporting thresholds, timing patterns suggesting avoidance. Keywords: 'structuring', 'smurfing', 'split transactions', '$9,000 deposits', 'avoiding CTR', 'breaking up deposits'.",
  "composes_with": ["DIR.AUDIT.007", "INST.STRUCT.001"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 97,
    "version": "1.0.0",
    "regulatory_basis": "31 USC 5324 - Structuring Transactions"
  }
}
```

---

## TRG.AUDIT.008 - High-Risk Customer Review

```json
{
  "id": "TRG.AUDIT.008",
  "type": "TRIGGER",
  "name": "High-Risk Customer Review",
  "description": "Activates when high-risk customer categorization needs validation",
  "content": "Activate for: 'high-risk customer', 'PEP screening' (Politically Exposed Person), 'money service business', 'MSB account', 'cannabis business', 'cryptocurrency exchange', 'cash-intensive business', 'check casher', 'money transmitter', 'high-risk industry', 'enhanced due diligence required'.",
  "composes_with": ["DIR.AUDIT.008", "INST.RISK.001"],
  "metadata": {
    "domain": "risk-assessment",
    "priority": 93,
    "version": "1.0.0",
    "regulatory_basis": "FFIEC BSA/AML Examination Manual - Risk Assessment"
  }
}
```

---

## TRG.AUDIT.009 - Wire Transfer Review

```json
{
  "id": "TRG.AUDIT.009",
  "type": "TRIGGER",
  "name": "Wire Transfer Review",
  "description": "Activates when wire transfer compliance needs verification",
  "content": "Activate for: 'wire transfer review', 'international wire', 'SWIFT transfer', 'remittance analysis', 'cross-border payment', 'wire to high-risk country', 'large wire transfer', 'beneficiary verification'. Include domestic wires >$3,000 and all international wires.",
  "composes_with": ["DIR.AUDIT.009", "INST.WIRE.001"],
  "metadata": {
    "domain": "transaction-analysis",
    "priority": 92,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1010.410 - Recordkeeping for Funds Transfers"
  }
}
```

---

## TRG.AUDIT.010 - Elder Financial Exploitation Check

```json
{
  "id": "TRG.AUDIT.010",
  "type": "TRIGGER",
  "name": "Elder Financial Exploitation Check",
  "description": "Activates when elder abuse indicators need assessment",
  "content": "Activate for: accounts held by customers 65+, sudden changes in elderly customer behavior, new authorized signers on elder accounts, unusual withdrawals from elder accounts, caregiver access concerns, 'elder financial abuse', 'financial exploitation', suspicious activity involving seniors.",
  "composes_with": ["DIR.AUDIT.010", "INST.ELDER.001"],
  "metadata": {
    "domain": "fraud-detection",
    "priority": 96,
    "version": "1.0.0",
    "regulatory_basis": "FinCEN Advisory FIN-2011-A003 - Elder Financial Exploitation"
  }
}
```

---

## TRG.AUDIT.011 - Reg CC Compliance Check

```json
{
  "id": "TRG.AUDIT.011",
  "type": "TRIGGER",
  "name": "Reg CC Compliance Check",
  "description": "Activates when funds availability compliance needs verification",
  "content": "Activate for: 'hold on funds', 'Reg CC compliance', 'funds availability', 'when will funds be available', 'check hold', 'exception hold', 'hold notice', 'availability schedule'. Review deposit holds, hold disclosures, exception hold documentation.",
  "composes_with": ["DIR.AUDIT.011", "INST.REGCC.001"],
  "metadata": {
    "domain": "regulatory-compliance",
    "priority": 85,
    "version": "1.0.0",
    "regulatory_basis": "12 CFR Part 229 - Availability of Funds"
  }
}
```

---

## TRG.AUDIT.012 - Reg E Error Resolution Review

```json
{
  "id": "TRG.AUDIT.012",
  "type": "TRIGGER",
  "name": "Reg E Error Resolution Review",
  "description": "Activates when electronic transfer dispute handling needs audit",
  "content": "Activate for: 'Reg E dispute', 'unauthorized transaction', 'error resolution', 'ATM dispute', 'debit card fraud', 'electronic transfer error', 'provisional credit', 'investigation timeline'. Review 10-day provisional credit, 45/90-day investigation timelines, consumer notifications.",
  "composes_with": ["DIR.AUDIT.012", "INST.REGE.001"],
  "metadata": {
    "domain": "consumer-protection",
    "priority": 88,
    "version": "1.0.0",
    "regulatory_basis": "12 CFR Part 1005 - Electronic Fund Transfers"
  }
}
```

---

## TRG.AUDIT.013 - Privacy Notice Compliance

```json
{
  "id": "TRG.AUDIT.013",
  "type": "TRIGGER",
  "name": "Privacy Notice Compliance",
  "description": "Activates when privacy and data protection compliance needs verification",
  "content": "Activate for: 'privacy notice', 'GLBA compliance', 'opt-out rights', 'information sharing', 'privacy disclosure', 'data security', 'customer information protection', 'breach notification'. Review annual privacy notices, opt-out processing, information sharing practices.",
  "composes_with": ["DIR.AUDIT.013", "INST.PRIV.001"],
  "metadata": {
    "domain": "privacy-compliance",
    "priority": 86,
    "version": "1.0.0",
    "regulatory_basis": "15 USC 6801 - Gramm-Leach-Bliley Act"
  }
}
```

---

## TRG.AUDIT.014 - Account Dormancy Review

```json
{
  "id": "TRG.AUDIT.014",
  "type": "TRIGGER",
  "name": "Account Dormancy Review",
  "description": "Activates when dormant account handling needs verification",
  "content": "Activate for: 'dormant accounts', 'inactive account', 'unclaimed property', 'escheatment', 'no activity for X months', 'abandoned account', 'dormancy notification'. Review dormancy criteria, reactivation procedures, escheatment compliance.",
  "composes_with": ["DIR.AUDIT.014", "INST.DORM.001"],
  "metadata": {
    "domain": "account-management",
    "priority": 80,
    "version": "1.0.0",
    "regulatory_basis": "State Unclaimed Property Laws"
  }
}
```

---

## TRG.AUDIT.015 - CIP Verification

```json
{
  "id": "TRG.AUDIT.015",
  "type": "TRIGGER",
  "name": "Customer Identification Program Verification",
  "description": "Activates when CIP compliance needs validation",
  "content": "Activate for: 'customer identification', 'CIP compliance', 'identity verification', 'ID document check', 'verification at account opening', '326 compliance' (Section 326 of USA PATRIOT Act). Review identification documents, verification methods, CIP certification.",
  "composes_with": ["DIR.AUDIT.015", "INST.CIP.001"],
  "metadata": {
    "domain": "customer-due-diligence",
    "priority": 94,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1020.220 - Customer Identification Program"
  }
}
```

---

## TRG.AUDIT.016 - BSA Officer Review

```json
{
  "id": "TRG.AUDIT.016",
  "type": "TRIGGER",
  "name": "BSA Officer Designation Review",
  "description": "Activates when BSA compliance program structure needs verification",
  "content": "Activate for: 'BSA officer designation', 'compliance program structure', 'BSA officer qualifications', 'compliance officer authority', 'board reporting', 'BSA program elements'. Review officer designation, qualifications, authority, reporting lines, board oversight.",
  "composes_with": ["DIR.AUDIT.016", "INST.BSA.001"],
  "metadata": {
    "domain": "program-structure",
    "priority": 91,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1020.210 - BSA Compliance Program"
  }
}
```

---

## TRG.AUDIT.017 - Independent Testing Review

```json
{
  "id": "TRG.AUDIT.017",
  "type": "TRIGGER",
  "name": "Independent Testing Review",
  "description": "Activates when independent audit/testing needs validation",
  "content": "Activate for: 'independent testing', 'BSA audit', 'third-party review', 'independent audit', 'testing scope', 'auditor qualifications', 'audit findings', 'testing frequency'. Review independence, scope, qualifications, findings, management response.",
  "composes_with": ["DIR.AUDIT.017", "INST.TEST.001"],
  "metadata": {
    "domain": "audit-quality",
    "priority": 89,
    "version": "1.0.0",
    "regulatory_basis": "FFIEC BSA/AML - Independent Testing"
  }
}
```

---

## TRG.AUDIT.018 - Training Program Review

```json
{
  "id": "TRG.AUDIT.018",
  "type": "TRIGGER",
  "name": "BSA Training Program Review",
  "description": "Activates when BSA/AML training compliance needs verification",
  "content": "Activate for: 'BSA training', 'compliance training', 'employee training records', 'training program', 'new employee orientation', 'annual training', 'role-specific training'. Review training frequency, content, attendance, testing, documentation.",
  "composes_with": ["DIR.AUDIT.018", "INST.TRAIN.001"],
  "metadata": {
    "domain": "program-structure",
    "priority": 84,
    "version": "1.0.0",
    "regulatory_basis": "FFIEC BSA/AML - Training"
  }
}
```

---

## TRG.AUDIT.019 - Risk Assessment Validation

```json
{
  "id": "TRG.AUDIT.019",
  "type": "TRIGGER",
  "name": "BSA Risk Assessment Validation",
  "description": "Activates when institutional risk assessment needs review",
  "content": "Activate for: 'BSA risk assessment', 'AML risk profile', 'risk assessment methodology', 'risk rating validation', 'inherent risk', 'residual risk', 'risk assessment update'. Review methodology, risk factors, rating criteria, periodic updates.",
  "composes_with": ["DIR.AUDIT.019", "INST.RISKA.001"],
  "metadata": {
    "domain": "risk-assessment",
    "priority": 92,
    "version": "1.0.0",
    "regulatory_basis": "FFIEC BSA/AML - Risk Assessment"
  }
}
```

---

## TRG.AUDIT.020 - Transaction Monitoring System Review

```json
{
  "id": "TRG.AUDIT.020",
  "type": "TRIGGER",
  "name": "Transaction Monitoring System Review",
  "description": "Activates when automated monitoring system needs validation",
  "content": "Activate for: 'transaction monitoring system', 'automated alerts', 'monitoring rules', 'alert tuning', 'scenario testing', 'false positives', 'monitoring thresholds', 'system validation'. Review system rules, parameters, alert quality, tuning, validation.",
  "composes_with": ["DIR.AUDIT.020", "INST.MONSYS.001"],
  "metadata": {
    "domain": "technology-controls",
    "priority": 90,
    "version": "1.0.0",
    "regulatory_basis": "FFIEC BSA/AML - Information Systems"
  }
}
```

---

## TRG.AUDIT.021 - Account Closure Review

```json
{
  "id": "TRG.AUDIT.021",
  "type": "TRIGGER",
  "name": "Account Closure Procedures Review",
  "description": "Activates when account closure compliance needs verification",
  "content": "Activate for: 'account closure', 'exit procedures', 'closure documentation', 'SAR filing before closure', 'regulatory notification', 'suspicious closure', 'closed account review'. Review closure reasons, documentation, SAR filing, notifications, escheatment.",
  "composes_with": ["DIR.AUDIT.021", "INST.CLOSE.001"],
  "metadata": {
    "domain": "account-management",
    "priority": 82,
    "version": "1.0.0",
    "regulatory_basis": "FinCEN - Account Termination"
  }
}
```

---

## TRG.AUDIT.022 - Correspondent Banking Review

```json
{
  "id": "TRG.AUDIT.022",
  "type": "TRIGGER",
  "name": "Correspondent Banking Due Diligence",
  "description": "Activates when correspondent account relationships need review",
  "content": "Activate for: 'correspondent banking', 'foreign bank account', 'correspondent due diligence', 'FCPA account', 'enhanced due diligence', 'correspondent account monitoring', 'foreign correspondent'. Review due diligence, enhanced procedures, monitoring, documentation.",
  "composes_with": ["DIR.AUDIT.022", "INST.CORR.001"],
  "metadata": {
    "domain": "specialized-accounts",
    "priority": 91,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1010.610 - Due Diligence for Correspondent Accounts"
  }
}
```

---

## TRG.AUDIT.023 - Private Banking Review

```json
{
  "id": "TRG.AUDIT.023",
  "type": "TRIGGER",
  "name": "Private Banking Account Due Diligence",
  "description": "Activates when private banking relationships need compliance review",
  "content": "Activate for: 'private banking', 'high net worth accounts', 'PB account', 'senior foreign political figure', 'SFPF', 'enhanced scrutiny', 'private banking due diligence'. Review due diligence, PEP screening, enhanced monitoring, documentation.",
  "composes_with": ["DIR.AUDIT.023", "INST.PB.001"],
  "metadata": {
    "domain": "specialized-accounts",
    "priority": 93,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1010.620 - Due Diligence for Private Banking"
  }
}
```

---

## TRG.AUDIT.024 - Suspicious Activity Investigation

```json
{
  "id": "TRG.AUDIT.024",
  "type": "TRIGGER",
  "name": "Suspicious Activity Investigation Review",
  "description": "Activates when SAR investigation process needs validation",
  "content": "Activate for: 'SAR investigation', 'alert investigation', 'suspicious activity research', 'investigation documentation', 'escalation procedures', 'SAR decision process', 'investigation timeline'. Review investigation procedures, documentation, decision criteria, filing timelines.",
  "composes_with": ["DIR.AUDIT.024", "INST.SARINV.001"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 95,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1020.320 - SAR Filing Requirements"
  }
}
```

---

# PART 2: DIRECTIVES (DIR) - 18 BLOCKS

**Purpose:** Directives define goals and objectives - what outcomes the audit should achieve.

---

## DIR.AUDIT.001 - Verify Account Opening Compliance

```json
{
  "id": "DIR.AUDIT.001",
  "type": "DIRECTIVE",
  "name": "Verify Account Opening Compliance",
  "description": "Ensures account was opened in compliance with all requirements",
  "content": "GOAL: Confirm account opening procedures followed regulatory requirements and institutional policy. Success means: all required documentation present, proper identification verified, beneficial owners identified (if applicable), account type appropriate for customer, authorizations valid. Prioritize: CIP compliance, beneficial ownership, risk rating accuracy.",
  "composes_with": ["INST.ACCT.001", "INST.ACCT.002", "VER.AUDIT.001"],
  "metadata": {
    "domain": "account-verification",
    "priority": 100,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.002 - Identify Transaction Anomalies

```json
{
  "id": "DIR.AUDIT.002",
  "type": "DIRECTIVE",
  "name": "Identify Transaction Anomalies",
  "description": "Detect unusual or suspicious transaction patterns",
  "content": "GOAL: Identify transactions or patterns that deviate from expected customer behavior or violate regulatory thresholds. Success means: structuring patterns detected, large transactions flagged, velocity anomalies identified, risk-scored appropriately. Prioritize: regulatory violations, money laundering indicators, fraud patterns.",
  "composes_with": ["INST.TXN.001", "INST.TXN.002", "INST.STRUCT.001"],
  "metadata": {
    "domain": "transaction-analysis",
    "priority": 100,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.003 - Validate CTR Compliance

```json
{
  "id": "DIR.AUDIT.003",
  "type": "DIRECTIVE",
  "name": "Validate Currency Transaction Reporting Compliance",
  "description": "Ensures CTR requirements properly followed",
  "content": "GOAL: Verify all currency transactions >$10,000 properly reported to FinCEN within 15 days. Success means: all reportable transactions identified, CTRs filed timely, forms complete and accurate, aggregation rules applied correctly, exemptions properly documented. Prioritize: filing compliance, accuracy, timeliness.",
  "composes_with": ["INST.CTR.001", "INST.CTR.002", "VER.AUDIT.002"],
  "metadata": {
    "domain": "compliance-verification",
    "priority": 95,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.004 - Assess SAR Filing Appropriateness

```json
{
  "id": "DIR.AUDIT.004",
  "type": "DIRECTIVE",
  "name": "Assess Suspicious Activity Report Filing Appropriateness",
  "description": "Determines if SAR filing decision was correct",
  "content": "GOAL: Validate SAR filing decisions (both filed and not filed) align with regulatory requirements and suspicious activity indicators. Success means: appropriate activities reported within 30 days, investigations documented, no missed reportable activity, decision rationale clear. Prioritize: regulatory compliance, investigation quality, timeliness.",
  "composes_with": ["INST.SAR.001", "INST.SAR.002", "INST.SARINV.001"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 98,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.005 - Confirm OFAC Screening Compliance

```json
{
  "id": "DIR.AUDIT.005",
  "type": "DIRECTIVE",
  "name": "Confirm OFAC Screening Compliance",
  "description": "Validates sanctions screening procedures followed",
  "content": "GOAL: Ensure customers and transactions screened against OFAC SDN list and sanctions programs at account opening and ongoing. Success means: screening performed at required intervals, matches investigated, documentation complete, blocking actions taken when required. Prioritize: screening completeness, match resolution, blocking compliance.",
  "composes_with": ["INST.OFAC.001", "INST.OFAC.002", "VER.AUDIT.003"],
  "metadata": {
    "domain": "sanctions-compliance",
    "priority": 99,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.006 - Validate Beneficial Ownership Compliance

```json
{
  "id": "DIR.AUDIT.006",
  "type": "DIRECTIVE",
  "name": "Validate Beneficial Ownership Compliance",
  "description": "Ensures legal entity beneficial owners properly identified",
  "content": "GOAL: Confirm legal entity customers have beneficial ownership information collected and verified per FinCEN requirements. Success means: certification form obtained, beneficial owners identified (25% ownership or control), information verified, documentation retained. Prioritize: form completeness, ownership verification, periodic updates.",
  "composes_with": ["INST.BEN.001", "INST.BEN.002", "VER.AUDIT.004"],
  "metadata": {
    "domain": "customer-due-diligence",
    "priority": 94,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.007 - Detect Structuring Activity

```json
{
  "id": "DIR.AUDIT.007",
  "type": "DIRECTIVE",
  "name": "Detect Structuring Activity",
  "description": "Identifies patterns suggesting CTR avoidance",
  "content": "GOAL: Identify transaction patterns that suggest deliberate structuring to avoid CTR filing requirements. Success means: related transactions aggregated, patterns identified, timing analysis complete, SAR filed if structuring confirmed. Prioritize: pattern detection, relationship identification, regulatory reporting.",
  "composes_with": ["INST.STRUCT.001", "INST.STRUCT.002", "DIR.AUDIT.004"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 97,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.008 - Assess Customer Risk Rating

```json
{
  "id": "DIR.AUDIT.008",
  "type": "DIRECTIVE",
  "name": "Assess Customer Risk Rating Accuracy",
  "description": "Validates risk classification appropriate for customer",
  "content": "GOAL: Ensure customer risk rating accurately reflects actual risk based on customer type, products, geography, transaction patterns. Success means: risk factors properly evaluated, rating methodology followed, enhanced due diligence applied to high-risk, monitoring frequency appropriate. Prioritize: rating accuracy, EDD compliance, monitoring alignment.",
  "composes_with": ["INST.RISK.001", "INST.RISK.002", "INST.RISK.003"],
  "metadata": {
    "domain": "risk-assessment",
    "priority": 93,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.009 - Review Wire Transfer Compliance

```json
{
  "id": "DIR.AUDIT.009",
  "type": "DIRECTIVE",
  "name": "Review Wire Transfer Compliance",
  "description": "Validates wire transfer recordkeeping and procedures",
  "content": "GOAL: Confirm wire transfers comply with recordkeeping requirements, screening procedures, and risk monitoring. Success means: originator/beneficiary information complete, records retained, screening performed, high-risk wires identified, documentation complete. Prioritize: recordkeeping compliance, screening, high-risk identification.",
  "composes_with": ["INST.WIRE.001", "INST.WIRE.002", "VER.AUDIT.005"],
  "metadata": {
    "domain": "transaction-analysis",
    "priority": 92,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.010 - Evaluate Elder Protection Procedures

```json
{
  "id": "DIR.AUDIT.010",
  "type": "DIRECTIVE",
  "name": "Evaluate Elder Financial Protection Procedures",
  "description": "Assesses elder financial exploitation detection and response",
  "content": "GOAL: Validate procedures exist and work effectively to detect and respond to elder financial exploitation. Success means: monitoring procedures in place, red flags identified, escalation protocols followed, protective actions taken when warranted, reporting to authorities when appropriate. Prioritize: detection effectiveness, response timeliness, protective measures.",
  "composes_with": ["INST.ELDER.001", "INST.ELDER.002", "DIR.AUDIT.004"],
  "metadata": {
    "domain": "fraud-detection",
    "priority": 96,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.011 - Verify Reg CC Compliance

```json
{
  "id": "DIR.AUDIT.011",
  "type": "DIRECTIVE",
  "name": "Verify Funds Availability Compliance",
  "description": "Ensures deposit hold procedures comply with Reg CC",
  "content": "GOAL: Confirm funds availability procedures follow Regulation CC requirements for hold periods, notices, and exceptions. Success means: availability schedules correct, hold notices provided, exception holds documented, disclosures at account opening, compliance with timing requirements. Prioritize: notice compliance, hold period accuracy, documentation.",
  "composes_with": ["INST.REGCC.001", "INST.REGCC.002", "VER.AUDIT.006"],
  "metadata": {
    "domain": "regulatory-compliance",
    "priority": 85,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.012 - Validate Reg E Compliance

```json
{
  "id": "DIR.AUDIT.012",
  "type": "DIRECTIVE",
  "name": "Validate Electronic Transfer Error Resolution Compliance",
  "description": "Ensures Reg E dispute procedures properly followed",
  "content": "GOAL: Confirm electronic fund transfer error resolution follows Regulation E requirements for provisional credit, investigation timelines, and consumer notifications. Success means: 10-day provisional credit provided, 45/90-day timelines met, notifications sent, investigations documented, resolutions appropriate. Prioritize: timeline compliance, provisional credit, notifications.",
  "composes_with": ["INST.REGE.001", "INST.REGE.002", "VER.AUDIT.007"],
  "metadata": {
    "domain": "consumer-protection",
    "priority": 88,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.013 - Assess Privacy Compliance

```json
{
  "id": "DIR.AUDIT.013",
  "type": "DIRECTIVE",
  "name": "Assess Privacy and Data Protection Compliance",
  "description": "Validates GLBA privacy requirements followed",
  "content": "GOAL: Ensure privacy notices provided, opt-out rights honored, information sharing disclosed, data security appropriate. Success means: annual notices delivered, opt-outs processed, disclosures accurate, security measures in place, breach procedures established. Prioritize: notice compliance, opt-out processing, data security.",
  "composes_with": ["INST.PRIV.001", "INST.PRIV.002", "VER.AUDIT.008"],
  "metadata": {
    "domain": "privacy-compliance",
    "priority": 86,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.014 - Review Program Structure

```json
{
  "id": "DIR.AUDIT.014",
  "type": "DIRECTIVE",
  "name": "Review BSA Compliance Program Structure",
  "description": "Validates four pillars of BSA compliance program",
  "content": "GOAL: Confirm BSA/AML compliance program includes all required elements: designated BSA Officer, written policies/procedures, training program, independent testing. Success means: all four pillars present, officer qualified and empowered, policies comprehensive and current, training effective, testing independent and thorough. Prioritize: program completeness, effectiveness, board oversight.",
  "composes_with": ["INST.BSA.001", "INST.TRAIN.001", "INST.TEST.001"],
  "metadata": {
    "domain": "program-structure",
    "priority": 90,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.015 - Validate CIP Procedures

```json
{
  "id": "DIR.AUDIT.015",
  "type": "DIRECTIVE",
  "name": "Validate Customer Identification Program Procedures",
  "description": "Ensures CIP requirements properly implemented",
  "content": "GOAL: Confirm Customer Identification Program collects and verifies required information at account opening. Success means: required information obtained (name, address, DOB, ID number), verification methods documented, CIP notice provided, certification completed, records retained 5 years. Prioritize: information completeness, verification quality, documentation.",
  "composes_with": ["INST.CIP.001", "INST.CIP.002", "VER.AUDIT.009"],
  "metadata": {
    "domain": "customer-due-diligence",
    "priority": 94,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.016 - Evaluate Risk Assessment Quality

```json
{
  "id": "DIR.AUDIT.016",
  "type": "DIRECTIVE",
  "name": "Evaluate BSA Risk Assessment Quality",
  "description": "Validates institutional risk assessment methodology and results",
  "content": "GOAL: Ensure BSA/AML risk assessment comprehensively evaluates ML/TF risks based on products, services, customers, geographic locations. Success means: methodology documented, risk factors identified, inherent and residual risk assessed, updated periodically, program tailored to risks. Prioritize: methodology soundness, comprehensiveness, currency.",
  "composes_with": ["INST.RISKA.001", "INST.RISKA.002", "VER.AUDIT.010"],
  "metadata": {
    "domain": "risk-assessment",
    "priority": 92,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.017 - Verify Transaction Monitoring Effectiveness

```json
{
  "id": "DIR.AUDIT.017",
  "type": "DIRECTIVE",
  "name": "Verify Transaction Monitoring System Effectiveness",
  "description": "Validates automated monitoring detects suspicious activity",
  "content": "GOAL: Confirm transaction monitoring system configured appropriately, generates quality alerts, detects suspicious activity effectively. Success means: scenarios appropriate for risk profile, parameters tuned properly, alerts investigated timely, false positive rate acceptable, system validated periodically. Prioritize: detection effectiveness, alert quality, validation.",
  "composes_with": ["INST.MONSYS.001", "INST.MONSYS.002", "INST.MONSYS.003"],
  "metadata": {
    "domain": "technology-controls",
    "priority": 90,
    "version": "1.0.0"
  }
}
```

---

## DIR.AUDIT.018 - Document Findings Completely

```json
{
  "id": "DIR.AUDIT.018",
  "type": "DIRECTIVE",
  "name": "Document All Audit Findings Completely",
  "description": "Ensures comprehensive documentation of audit work and results",
  "content": "GOAL: Create complete, accurate, objective documentation of all audit findings with evidence, impact assessment, and recommendations. Success means: findings clearly documented, severity assigned, evidence referenced, recommendations actionable, management response obtained, audit trail complete. Prioritize: accuracy, completeness, objectivity.",
  "composes_with": ["INST.DOC.001", "INST.DOC.002", "BP.AUDIT.001"],
  "metadata": {
    "domain": "documentation",
    "priority": 100,
    "version": "1.0.0"
  }
}
```

---

**[Continued in next file - Instructions, Subjects, Primary, Philosophy, Blueprints, Verifications]**
