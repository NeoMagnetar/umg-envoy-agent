# COMPLIANCE CHECKLISTS
## Bank Account Compliance Auditor

**Ready-to-Use Audit Checklists**

---

## NEW ACCOUNT OPENING CHECKLIST

**Account Information:**
- Account Number: ________________
- Account Type: ________________
- Opening Date: ________________
- Customer Name: ________________

### Customer Identification Program (CIP) - 31 CFR 1020.220

□ Customer name obtained and verified
□ Date of birth obtained (individuals)
□ Address obtained and verified
□ Identification number obtained (SSN, EIN, passport, etc.)
□ Identification method documented
□ Government-issued ID reviewed and copied
□ CIP certification completed within 30 days of account opening
□ CIP notice provided to customer

**Documentation:**
- ID Type: ________________
- ID Number: ________________
- Expiration Date: ________________
- Verification Method: ________________

### Beneficial Ownership - 31 CFR 1010.230 (Legal Entities Only)

□ Account type requires beneficial ownership (corporation, LLC, partnership, trust)
□ Exclusions verified if claimed (publicly traded, government, etc.)
□ Certification of Beneficial Owners form obtained
□ Control prong individual identified (if applicable)
□ Ownership prong individuals identified (25%+ owners)
□ Each beneficial owner's information complete (name, DOB, address, ID number)
□ Beneficial owners verified (ID documents obtained)
□ Form signed and dated by authorized person
□ Form obtained at/near account opening

**Beneficial Owners Identified:**
1. Name: ________________ Ownership: _____%
2. Name: ________________ Ownership: _____%
3. Name: ________________ Ownership: _____%
4. Name: ________________ Ownership: _____%

### OFAC Screening

□ Customer name screened against SDN list at account opening
□ Beneficial owners screened (if applicable)
□ Screening results documented
□ Any matches investigated and resolved
□ Screening performed BEFORE account opened

**Screening Date:** ________________
**Result:** □ Clear  □ Match (investigated and cleared)

### Risk Assessment

□ Customer risk rating assigned
□ Risk factors documented:
  - Customer type: ________________
  - Industry/occupation: ________________
  - Products/services: ________________
  - Geographic locations: ________________
  - Expected activity: ________________
□ Risk rating: □ Low  □ Medium  □ High
□ Enhanced due diligence applied (if high-risk)
□ Monitoring frequency determined

### Account Opening Procedures

□ Account opened by authorized personnel
□ Initial deposit amount: $________________
□ Source of initial deposit documented
□ Account type appropriate for customer
□ All required signatures obtained
□ Account disclosures provided
□ Privacy notice provided (GLBA)

### Findings

□ No deficiencies found
□ Deficiencies identified (list below):

**Deficiency:** ________________
**Severity:** □ Critical  □ High  □ Medium  □ Low

**Auditor:** ________________  
**Date:** ________________  
**Overall Compliance:** □ Compliant  □ Deficient

---

## CURRENCY TRANSACTION REPORT (CTR) CHECKLIST

**Review Period:** ________________

### Transaction Identification

□ All currency transactions ≥$10,000 identified
□ Multiple currency transactions by same person aggregated (same day)
□ Related transactions identified and aggregated
□ Exempt customers identified (if applicable)
□ Exemption eligibility verified
□ Exemption properly documented

**Total Reportable Transactions:** ______

### CTR Filing Compliance

For each reportable transaction:

**Transaction Date:** ________________
**Transaction Amount:** $________________
**Customer:** ________________

□ CTR filed within 15 calendar days
□ Filing date: ________________ (Days after transaction: _____)
□ CTR form complete (all required fields)
□ Customer identification accurate
□ Transaction details accurate
□ Multiple transactions properly listed (if aggregated)
□ Proper CTR type selected

**CTR Status:**
□ Filed timely and complete
□ Filed late (16-30 days)
□ Filed late (31-60 days)
□ Filed late (>60 days)
□ Not filed (CRITICAL)
□ Filed but incomplete

### Findings

**Total Transactions Reviewed:** ______
**CTRs Filed:** ______
**Late Filings:** ______
**Missing Filings:** ______
**Incomplete Filings:** ______

**Critical Issues:**
□ None
□ Missing CTR(s) - Number: ______
□ Severely late filing(s) (>60 days) - Number: ______

**Auditor:** ________________  
**Date:** ________________

---

## SUSPICIOUS ACTIVITY REPORT (SAR) CHECKLIST

**SAR Review Period:** ________________

### Investigation Quality

**Alert/Referral Date:** ________________
**Investigation Completion Date:** ________________
**Days to Complete:** ______

□ Investigation procedures documented
□ Sufficient information gathered
□ Appropriate sources consulted
□ Customer contacted (if safe and appropriate)
□ External information reviewed
□ Analysis logical and complete
□ Decision rationale clearly documented

### SAR Filing Decision

**Decision:** □ File SAR  □ Clear Alert  □ Continue Monitoring

If SAR Filed:

□ Filed within 30 days of initial detection
□ Filing date: ________________ (Days after detection: _____)
□ All required form fields completed
□ Narrative includes five W's (who, what, when, where, why)
□ Supporting documentation attached
□ Continuing activity monitoring established
□ Law enforcement contact info provided

### SAR Narrative Quality Assessment

□ Subject identification clear
□ Activity description detailed
□ Timeline complete
□ Suspicious indicators explained
□ Facts distinguished from suspicions
□ Written clearly for law enforcement use
□ Sufficient detail for follow-up

**Narrative Quality Score:** ___/5

If Alert Cleared:

□ Clearing rationale documented
□ Evidence supports clearing decision
□ Alternative explanations considered
□ No indicators of reportable activity remain

### Suspicious Activity Indicators Present

□ Structuring (avoiding CTR threshold)
□ Unusual transaction patterns
□ Inconsistent with customer profile
□ No apparent business purpose
□ Customer evasive about purpose
□ Rapid movement of funds
□ High-risk jurisdiction involvement
□ Round-dollar amounts suggesting structuring
□ Transactions inconsistent with business type
□ Other: ________________

**Total Indicators:** ______

### Findings

**Investigation Quality:** □ Excellent  □ Good  □ Adequate  □ Deficient

**Decision Appropriateness:** □ Agree  □ Disagree

**Timeline Compliance:** □ Yes  □ No (_____ days)

**Deficiencies:**
□ None
□ Investigation incomplete
□ SAR filed late
□ SAR narrative insufficient
□ Reportable activity not filed
□ Other: ________________

**Auditor:** ________________  
**Date:** ________________

---

## OFAC SCREENING CHECKLIST

**Review Period:** ________________

### Screening Frequency

□ Account opening screening performed (all new customers)
□ Transaction screening performed (wires, high-risk transactions)
□ Periodic rescreening performed (minimum annually)
□ Rescreening frequency: ________________

### Account Opening Screening

**Sample Accounts Reviewed:** ______

For each account:
□ Customer name screened before account opened
□ Beneficial owners screened (if legal entity)
□ Screening date documented
□ Screening results documented
□ System/vendor used: ________________

### Transaction Screening

**Sample Transactions Reviewed:** ______

For each transaction:
□ All parties screened (originator, beneficiary, intermediaries)
□ Screening performed BEFORE transaction processed
□ Screening results documented
□ High-risk transactions identified

### Match Resolution

**Potential Matches Reviewed:** ______

For each match:
□ Match investigated promptly
□ Comparison criteria documented
□ Decision maker authorized

If False Positive:
□ Clear distinguishing information documented
□ Clearing decision reasonable
□ Documentation sufficient

If True Match (Blocked Party):
□ Transaction/account blocked immediately
□ Compliance officer notified immediately
□ OFAC reported within 10 days
□ Funds frozen (not released)
□ Customer notification appropriate

### Findings

**Screening Coverage:**
□ Complete
□ Gaps identified: ________________

**Match Resolution Quality:**
□ Excellent
□ Deficient: ________________

**Critical Issues:**
□ None
□ Screening not performed before processing
□ True match not blocked
□ OFAC not notified timely
□ Funds improperly released

**Auditor:** ________________  
**Date:** ________________

---

## TRANSACTION MONITORING CHECKLIST

**Review Period:** ________________

### Transaction Analysis

**Transactions Reviewed:** ______
**Accounts Analyzed:** ______

### Volume Analysis

□ Transaction volumes calculated
□ Baseline/expected activity determined
□ Variances calculated
□ Anomalies flagged (>3x baseline)

**Accounts with Volume Anomalies:** ______

### Large Transactions (≥$10,000)

□ All large transactions identified
□ Business justification reviewed
□ Source of funds documented
□ CTR compliance verified

**Large Transactions Found:** ______
**CTRs Required:** ______
**CTRs Filed:** ______

### Structuring Detection

□ Just-under-threshold transactions identified ($9,000-$9,999)
□ Multiple same-day transactions analyzed
□ Timing patterns reviewed
□ Aggregation rules applied
□ Customer explanations obtained

**Potential Structuring Cases:** ______

### Wire Transfer Review

□ Domestic wires reviewed (sample)
□ International wires reviewed (all or sample)
□ Originator information complete
□ Beneficiary information complete
□ High-risk jurisdictions flagged
□ OFAC screening verified

**Wire Transfers Reviewed:** ______
**High-Risk Wires:** ______

### Findings

**Transaction Anomalies:** ______
**CTR Compliance Issues:** ______
**Potential Structuring:** ______
**High-Risk Wires:** ______

**Recommendations:**
□ No action needed
□ Enhanced monitoring required
□ SAR investigation needed
□ Policy/procedure improvement

**Auditor:** ________________  
**Date:** ________________

---

## BSA PROGRAM STRUCTURE CHECKLIST

**Review Date:** ________________

### Four Pillars of BSA Compliance Program

#### 1. BSA Compliance Officer

□ BSA Officer designated in writing
□ Officer qualified (knowledge, experience, training)
□ Officer has adequate authority
□ Officer has adequate resources
□ Officer has direct board access
□ Reports to board at least annually
□ Officer responsibilities documented

**BSA Officer:** ________________
**Title:** ________________
**Designation Date:** ________________

#### 2. Policies, Procedures, and Controls

□ Written BSA/AML policy exists
□ Policy board-approved
□ Policy updated within last 12 months
□ Policy covers all required areas:
  □ Customer identification (CIP)
  □ Customer due diligence
  □ Beneficial ownership
  □ Ongoing monitoring
  □ Currency transaction reporting
  □ Suspicious activity reporting
  □ OFAC compliance
  □ Recordkeeping
  □ Information sharing (314(b))
□ Procedures detailed and operational
□ Internal controls effective

**Policy Version:** ________________
**Last Updated:** ________________
**Board Approval Date:** ________________

#### 3. Training Program

□ Training program documented
□ New employee orientation includes BSA
□ Annual training provided to all employees
□ Role-specific training provided
□ Training content appropriate
□ Training includes:
  □ Regulatory requirements
  □ Institution policies
  □ Identification of suspicious activity
  □ Reporting procedures
  □ Confidentiality requirements
□ Training attendance documented
□ Training effectiveness assessed

**Annual Training Date:** ________________
**Attendance Rate:** ______%

#### 4. Independent Testing

□ Independent audit/testing conducted
□ Testing performed by qualified party
□ Tester independent (not BSA Officer)
□ Testing conducted within last 12-18 months
□ Testing scope comprehensive:
  □ Program structure
  □ Risk assessment
  □ Customer due diligence
  □ Monitoring systems
  □ CTR/SAR compliance
  □ OFAC compliance
  □ Training
  □ Recordkeeping
□ Findings documented
□ Management response obtained
□ Corrective actions tracked

**Last Testing Date:** ________________
**Testing Firm/Auditor:** ________________
**Critical Findings:** ______
**Status of Corrective Actions:** ________________

### Risk Assessment

□ BSA/AML risk assessment completed
□ Risk assessment updated within last 12-24 months
□ Methodology documented
□ Risk factors considered:
  □ Customer types
  □ Products and services
  □ Geographic locations
  □ Delivery channels
□ Inherent and residual risk assessed
□ Program tailored to risk profile

**Risk Assessment Date:** ________________
**Overall Risk Rating:** □ Low  □ Moderate  □ High

### Board Oversight

□ Board receives regular BSA/AML reporting
□ Board reviews risk assessment
□ Board reviews audit/testing results
□ Board approves policies
□ Board minutes reflect BSA oversight

**Last Board Presentation:** ________________

### Findings

**Program Pillars Complete:** ___/4

**Critical Deficiencies:**
□ None
□ No designated BSA Officer
□ Policy outdated or incomplete
□ No training program
□ No independent testing
□ Risk assessment missing/outdated

**Recommendations:** ________________

**Auditor:** ________________  
**Date:** ________________  
**Overall Program Rating:** □ Strong  □ Satisfactory  □ Needs Improvement  □ Weak

---

## QUICK SEVERITY ASSESSMENT GUIDE

Use this guide to assign severity to findings:

### CRITICAL
- Missing CTR for reportable transaction
- Blocked OFAC party allowed to transact
- SAR not filed for clear suspicious activity
- No BSA Officer designated
- Account opened without CIP verification

### HIGH
- CTR filed >30 days late
- SAR filed >30 days late
- Missing beneficial ownership for legal entity
- No OFAC screening at account opening
- No independent testing in >18 months

### MEDIUM
- CTR incomplete but filed timely
- Delayed KYC refresh (>policy requirement)
- Incomplete CIP documentation
- Risk rating not assigned or inaccurate
- Training not provided annually

### LOW
- Transaction documentation could be more detailed
- Filing procedure could be improved
- Minor form errors on CTR/SAR
- Policy wording could be clearer

### INFORMATIONAL
- Process efficiency opportunities
- Best practice suggestions
- Training topic recommendations

---

**END OF CHECKLISTS**
