# OPENCLAW DEPLOYMENT GUIDE
## Bank Account Compliance Auditor Sleeve

**Target Platform:** OpenClaw 0.4.0+  
**Deployment Time:** 15-30 minutes  
**Difficulty:** Intermediate

---

## QUICK START (5 Minutes)

```powershell
# 1. Navigate to OpenClaw directory
cd $env:USERPROFILE\.openclaw

# 2. Copy system prompt
cp [path-to-package]\system-prompt.txt .\prompts\bank-auditor-prompt.txt

# 3. Copy config template
cp [path-to-package]\openclaw-config.json .\bank-auditor-config.json

# 4. Edit config with your API key
notepad bank-auditor-config.json
# Add your OpenAI API key in the "api_key" field

# 5. Start OpenClaw with this config
openclaw --config bank-auditor-config.json
```

---

## DETAILED SETUP

### Step 1: Verify Prerequisites

**Check OpenClaw installation:**
```powershell
openclaw --version
# Should show 0.4.0 or higher
```

**Check Python:**
```powershell
python --version
# Should show 3.8+
```

**Check API key:**
```powershell
echo $env:OPENAI_API_KEY
# Should display your key (or set it now)
```

**If OpenAI API key not set:**
```powershell
[Environment]::SetEnvironmentVariable("OPENAI_API_KEY", "sk-your-key-here", "User")
```

---

### Step 2: Install Package Files

**Extract package:**
```powershell
# Extract the zip to a working directory
Expand-Archive bank-audit-sleeve-v1.0.zip -DestinationPath C:\openclaw-sleeves\
cd C:\openclaw-sleeves\bank-audit-sleeve-package
```

**Copy system prompt:**
```powershell
# Create prompts directory if doesn't exist
New-Item -ItemType Directory -Path $env:USERPROFILE\.openclaw\prompts -Force

# Copy system prompt
Copy-Item system-prompt.txt $env:USERPROFILE\.openclaw\prompts\bank-auditor.txt
```

---

### Step 3: Configure OpenClaw

**Copy config template:**
```powershell
Copy-Item openclaw-config.json $env:USERPROFILE\.openclaw\bank-auditor-config.json
```

**Edit configuration:**
```powershell
notepad $env:USERPROFILE\.openclaw\bank-auditor-config.json
```

**Modify these settings:**
```json
{
  "model": {
    "provider": "openai",
    "name": "gpt-4o",  // or "gpt-4o-mini" for cost savings
    "temperature": 0.3,
    "max_tokens": 8192
  },
  "api": {
    "openai": {
      "api_key": "sk-YOUR-KEY-HERE"  // ← Add your actual key
    }
  },
  "system_prompt_file": "prompts/bank-auditor.txt",
  "tools": {
    "file_read": { "enabled": true, "auto_approve": true },
    "file_write": { "enabled": true, "auto_approve": false },
    "web_search": { "enabled": false }  // Not needed for auditing
  }
}
```

---

### Step 4: Test Installation

**Start OpenClaw:**
```powershell
cd $env:USERPROFILE\.openclaw
openclaw --config bank-auditor-config.json
```

**Test with simple query:**
```
YOU: What audit capabilities do you have?

AGENT: I am a Bank Account Compliance Auditor with the following capabilities:
[Should describe 7 NeoStacks and audit functions]
```

**Test with data:**
```
YOU: Here's a sample transaction:
Date: 2026-03-15
Amount: $9,500 (cash deposit)
Customer: Business account

AGENT: [Should analyze for structuring potential, CTR requirements, etc.]
```

---

### Step 5: Production Configuration

**For production use, adjust settings:**

**Model Selection:**
```json
{
  "model": {
    "name": "gpt-4o",  // More accurate for compliance work
    "temperature": 0.2  // Lower for consistency
  }
}
```

**Token Optimization:**
```json
{
  "optimization": {
    "cache_prompt": true,  // Reduce costs
    "max_history_messages": 15,  // Keep context manageable
    "compress_history_after": 10
  }
}
```

**Logging:**
```json
{
  "logging": {
    "enabled": true,
    "level": "INFO",
    "log_file": "logs/bank-auditor-{date}.log",
    "audit_trail": true  // IMPORTANT for compliance
  }
}
```

---

## USAGE PATTERNS

### Pattern 1: Single Account Audit

**Provide data:**
```
Audit this account:
- Account #: ****1234
- Type: Business Checking
- Opened: 2024-01-15
- Customer: ABC Corp LLC
- Initial Deposit: $5,000

[Attach: account opening documents]
```

**Agent will:**
1. Activate Account Verification Stack (S.01)
2. Check KYC/CIP compliance
3. Verify beneficial ownership (legal entity)
4. Review account opening procedures
5. Assess risk rating
6. Generate compliance scorecard

---

### Pattern 2: Transaction Analysis

**Provide data:**
```
Review these transactions for compliance:

[Attach: transactions.csv]
Columns: Date, Amount, Type, Description, Customer_ID
```

**Agent will:**
1. Activate Transaction Analysis Stack (S.02)
2. Analyze volume patterns
3. Identify large transactions (≥$10k)
4. Detect structuring patterns
5. Score risk
6. Generate transaction audit report

---

### Pattern 3: CTR Compliance Review

**Provide data:**
```
Verify CTR compliance for March 2026:

[Attach: cash-transactions.csv]
[Attach: filed-ctrs.csv]
```

**Agent will:**
1. Activate Compliance Verification Stack (S.03)
2. Identify reportable transactions
3. Apply aggregation rules
4. Verify CTR filings (within 15 days)
5. Check form completeness
6. Generate CTR compliance report

---

### Pattern 4: SAR Quality Review

**Provide data:**
```
Review these SAR filings for quality:

[Attach: sar-cases/]
- Investigation notes
- SAR narratives
- Supporting documentation
```

**Agent will:**
1. Activate Suspicious Activity Detection Stack (S.05)
2. Review investigation quality
3. Assess SAR decision appropriateness
4. Evaluate narrative quality
5. Check timeline compliance
6. Generate SAR quality report

---

## TROUBLESHOOTING

### Issue: Agent not loading sleeve

**Symptoms:** Agent doesn't mention audit capabilities

**Solutions:**
```powershell
# 1. Verify system prompt loaded
cat $env:USERPROFILE\.openclaw\prompts\bank-auditor.txt

# 2. Check config points to correct prompt file
cat $env:USERPROFILE\.openclaw\bank-auditor-config.json | Select-String "system_prompt_file"

# 3. Restart OpenClaw with explicit config
openclaw --config bank-auditor-config.json --verbose
```

---

### Issue: "Insufficient tokens" error

**Cause:** Context window too small for sleeve + data

**Solutions:**
```json
// Option 1: Increase max_tokens
{
  "model": {
    "max_tokens": 16384  // Increase from 8192
  }
}

// Option 2: Use model with larger context
{
  "model": {
    "name": "gpt-4-turbo",  // 128k context
  }
}

// Option 3: Compress history more aggressively
{
  "optimization": {
    "max_history_messages": 8,  // Reduce from 15
    "compress_history_after": 5
  }
}
```

---

### Issue: File attachments not working

**Symptoms:** Agent can't read attached files

**Solutions:**
```json
// Ensure file tools enabled
{
  "tools": {
    "file_read": {
      "enabled": true,
      "auto_approve": true
    }
  }
}
```

**Check file format:**
- CSV: UTF-8 encoding, comma-delimited
- Excel: .xlsx format (not .xls)
- PDF: Text-based (not scanned images)

---

### Issue: Inconsistent audit results

**Cause:** Temperature too high

**Solution:**
```json
{
  "model": {
    "temperature": 0.2  // Lower = more consistent (0.0-0.4 recommended)
  }
}
```

---

### Issue: High API costs

**Solutions:**

**1. Use cheaper model for routine work:**
```json
{
  "model": {
    "name": "gpt-4o-mini",  // 80% cost reduction
    "fallback": "gpt-4o"  // Use for complex cases
  }
}
```

**2. Enable caching:**
```json
{
  "optimization": {
    "cache_prompt": true,  // Reuse system prompt
    "cache_ttl": 3600  // 1 hour cache
  }
}
```

**3. Limit history:**
```json
{
  "optimization": {
    "max_history_messages": 10  // Reduce context size
  }
}
```

---

## ADVANCED CONFIGURATION

### Multi-Auditor Setup

**Create profiles for different auditors:**

**auditor-1-config.json:**
```json
{
  "system_prompt_file": "prompts/bank-auditor.txt",
  "metadata": {
    "auditor_id": "AUDIT001",
    "auditor_name": "Jane Smith"
  },
  "logging": {
    "log_file": "logs/auditor-1-{date}.log"
  }
}
```

**auditor-2-config.json:**
```json
{
  "system_prompt_file": "prompts/bank-auditor.txt",
  "metadata": {
    "auditor_id": "AUDIT002",
    "auditor_name": "John Doe"
  },
  "logging": {
    "log_file": "logs/auditor-2-{date}.log"
  }
}
```

**Start sessions:**
```powershell
# Terminal 1
openclaw --config auditor-1-config.json

# Terminal 2
openclaw --config auditor-2-config.json
```

---

### Batch Processing

**Create batch audit script:**

**batch-audit.ps1:**
```powershell
# Batch audit multiple accounts
$accounts = Import-Csv accounts-to-audit.csv

foreach ($account in $accounts) {
    Write-Host "Auditing account: $($account.account_id)"
    
    $prompt = @"
Audit this account:
- Account ID: $($account.account_id)
- Type: $($account.account_type)
- Opened: $($account.open_date)
[Attach documents in: accounts/$($account.account_id)/]

Generate compliance scorecard.
"@
    
    # Send to OpenClaw API
    $result = Invoke-OpenClawAudit -Prompt $prompt -Config "bank-auditor-config.json"
    
    # Save result
    $result | Out-File "results\$($account.account_id)-audit-$(Get-Date -Format 'yyyyMMdd').txt"
}
```

---

### Integration with Audit Management System

**Export results to database:**

```powershell
# Parse audit results and insert to database
$auditResult = Get-Content "results\account-1234-audit.txt" | ConvertFrom-Json

Invoke-Sqlcmd -Query @"
INSERT INTO AuditFindings 
(account_id, audit_date, severity, category, finding, recommendation)
VALUES 
('$($auditResult.account_id)', 
 GETDATE(), 
 '$($auditResult.severity)', 
 '$($auditResult.category)', 
 '$($auditResult.finding)', 
 '$($auditResult.recommendation)')
"@
```

---

## PERFORMANCE TUNING

### Recommended Settings by Use Case

**High-Volume Transaction Analysis (1000+ transactions):**
```json
{
  "model": {
    "name": "gpt-4o-mini",  // Cost-effective
    "max_tokens": 16384
  },
  "optimization": {
    "cache_prompt": true,
    "batch_size": 100  // Process in batches
  }
}
```

**Critical Compliance Review (regulatory exam prep):**
```json
{
  "model": {
    "name": "gpt-4o",  // Maximum accuracy
    "temperature": 0.1  // Very consistent
  },
  "verification": {
    "double_check": true,  // Review all findings twice
    "peer_review": true
  }
}
```

**SAR Investigation Review:**
```json
{
  "model": {
    "name": "gpt-4o",
    "temperature": 0.3
  },
  "output": {
    "detailed_reasoning": true,  // Show analysis process
    "cite_sources": true
  }
}
```

---

## SECURITY BEST PRACTICES

### Data Protection

**1. Anonymize customer data:**
```powershell
# Replace account numbers
(Get-Content transactions.csv) -replace '\d{10,}', '****XXXX' | Set-Content transactions-anonymized.csv
```

**2. Encrypt audit logs:**
```powershell
# Enable log encryption in config
{
  "logging": {
    "encrypt": true,
    "encryption_key_file": "keys/audit-log.key"
  }
}
```

**3. Secure API keys:**
```powershell
# Never commit configs with keys to version control
# Use environment variables
{
  "api": {
    "openai": {
      "api_key": "${OPENAI_API_KEY}"  // Reference env variable
    }
  }
}
```

---

## MAINTENANCE

### Regular Updates

**Weekly:**
- Review audit logs
- Check for errors
- Validate API costs

**Monthly:**
- Update regulatory content (if regulations change)
- Review finding accuracy
- Tune configurations based on usage

**Quarterly:**
- Full system validation test
- Update documentation
- Retrain staff on any changes

---

## SUPPORT

**Documentation:**
- Full sleeve specification: `SLEEVE_SPECIFICATION.md`
- MOLT blocks reference: `MOLT_BLOCKS_COMPLETE.md`
- Quick reference: `quick-reference.md`

**Troubleshooting:**
- Check logs: `$env:USERPROFILE\.openclaw\logs\`
- Validate config: `openclaw --config bank-auditor-config.json --validate`
- Test mode: `openclaw --config bank-auditor-config.json --test`

---

**END OF DEPLOYMENT GUIDE**
