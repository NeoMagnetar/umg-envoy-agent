# MOLT BLOCKS LIBRARY - PART 2: INSTRUCTIONS
## Bank Account Compliance Auditor - SLV.BANK_AUDIT.COMPLIANCE.v1.0

**Block Type:** INSTRUCTION (INST)  
**Count:** 42 blocks  
**Purpose:** Step-by-step procedures for audit execution

---

# INSTRUCTIONS (INST) - 42 BLOCKS

**Purpose:** Instructions provide detailed procedural steps for executing audit tasks.

---

## INST.ACCT.001 - Account Opening Documentation Review

```json
{
  "id": "INST.ACCT.001",
  "type": "INSTRUCTION",
  "name": "Account Opening Documentation Review",
  "description": "Step-by-step account opening compliance verification",
  "content": "STEPS:\n1. Obtain account opening documentation package\n2. Verify account opening date and opening personnel\n3. Check CIP certification completed within 30 days\n4. Review identification documents (type, expiration, verification method)\n5. Confirm address verification completed\n6. Verify signature card/authorization documentation\n7. Check account type appropriate for customer profile\n8. Review initial deposit amount and source\n9. Confirm risk rating assigned\n10. Verify OFAC screening performed at opening\n11. For legal entities: confirm beneficial ownership obtained\n12. Document any deficiencies with specific citations\n13. Assign severity rating to findings\n14. Generate account opening compliance scorecard",
  "composes_with": ["TRG.AUDIT.001", "DIR.AUDIT.001", "SUBJ.ACCT.001"],
  "metadata": {
    "domain": "account-verification",
    "priority": 100,
    "version": "1.0.0",
    "estimated_time": "10-15 minutes per account"
  }
}
```

---

## INST.ACCT.002 - Account Status Validation Procedure

```json
{
  "id": "INST.ACCT.002",
  "type": "INSTRUCTION",
  "name": "Account Status Validation Procedure",
  "description": "Verify account status changes properly documented",
  "content": "STEPS:\n1. Review current account status (active/dormant/frozen/closed)\n2. Check account activity history (last 12 months)\n3. Verify dormancy criteria applied correctly (typically 12-24 months no activity)\n4. Review any status change documentation\n5. For dormant accounts: verify dormancy notice sent to customer\n6. For frozen accounts: verify freeze reason and authorization\n7. For closed accounts: verify closure documentation and escheatment compliance\n8. Check reactivation procedures followed (if applicable)\n9. Confirm status aligned with actual customer activity\n10. Document status accuracy and compliance",
  "composes_with": ["TRG.AUDIT.001", "DIR.AUDIT.001", "SUBJ.ACCT.002"],
  "metadata": {
    "domain": "account-verification",
    "priority": 85,
    "version": "1.0.0",
    "estimated_time": "5-8 minutes per account"
  }
}
```

---

## INST.TXN.001 - Transaction Volume Analysis

```json
{
  "id": "INST.TXN.001",
  "type": "INSTRUCTION",
  "name": "Transaction Volume Analysis Procedure",
  "description": "Analyze transaction volumes for anomalies",
  "content": "STEPS:\n1. Extract transaction data for analysis period (30/60/90 days)\n2. Calculate transaction counts by type (deposits, withdrawals, transfers, wires)\n3. Calculate total transaction dollar volumes\n4. Determine account baseline (historical average for similar accounts)\n5. Compare current volume to baseline\n6. Calculate variance percentage\n7. Flag accounts with >3x normal volume (REVIEW)\n8. Flag accounts with >5x normal volume (ESCALATE)\n9. Flag accounts with >10x normal volume (CRITICAL)\n10. Cross-reference volume changes with customer profile changes\n11. Identify sudden spikes in specific transaction types\n12. Document volume anomalies with supporting calculations\n13. Generate volume analysis report with flagged accounts",
  "composes_with": ["TRG.AUDIT.002", "DIR.AUDIT.002", "SUBJ.TXN.001"],
  "metadata": {
    "domain": "transaction-analysis",
    "priority": 95,
    "version": "1.0.0",
    "estimated_time": "15-30 minutes for 100-1000 transactions"
  }
}
```

---

## INST.TXN.002 - Large Transaction Review Procedure

```json
{
  "id": "INST.TXN.002",
  "type": "INSTRUCTION",
  "name": "Large Transaction Review Procedure",
  "description": "Review individual large transactions for compliance",
  "content": "STEPS:\n1. Identify all transactions ≥$10,000 in analysis period\n2. For each large transaction:\n   a. Transaction amount, date, type (cash/check/wire)\n   b. Customer account details\n   c. Transaction purpose/description\n   d. Source of funds (if documented)\n   e. Counterparty information\n3. For cash transactions ≥$10,000:\n   a. Verify CTR filed within 15 days\n   b. Check CTR form completeness\n   c. Verify accuracy of reported information\n4. Check for related transactions that aggregate to ≥$10,000\n5. Review multiple transactions $9,000-$9,999 for structuring indicators\n6. Assess transaction consistency with customer profile\n7. Document business justification (if available)\n8. Flag transactions lacking clear business purpose\n9. Generate large transaction review report\n10. Identify any CTR filing deficiencies",
  "composes_with": ["TRG.AUDIT.002", "DIR.AUDIT.003", "INST.CTR.001"],
  "metadata": {
    "domain": "transaction-analysis",
    "priority": 95,
    "version": "1.0.0",
    "estimated_time": "3-5 minutes per transaction"
  }
}
```

---

## INST.CTR.001 - CTR Filing Verification

```json
{
  "id": "INST.CTR.001",
  "type": "INSTRUCTION",
  "name": "Currency Transaction Report Filing Verification",
  "description": "Verify CTR filing compliance for reportable transactions",
  "content": "STEPS:\n1. Identify all currency transactions ≥$10,000 (single or aggregate)\n2. Apply aggregation rules:\n   a. Multiple currency transactions by/for same person same business day\n   b. Related transactions requiring aggregation\n3. For each reportable transaction:\n   a. Verify CTR filed within 15 calendar days\n   b. Check filing date against transaction date\n   c. Review CTR form for completeness (all required fields)\n   d. Verify customer identification accuracy\n   e. Check transaction details accuracy\n   f. Confirm proper CTR type selected\n4. Review exempt customer list:\n   a. Verify exemption eligibility\n   b. Check exemption properly documented\n   c. Confirm annual review completed\n5. Identify late filings (>15 days)\n6. Identify missing CTRs for reportable transactions\n7. Identify incomplete or inaccurate CTRs\n8. Document deficiencies by severity:\n   - CRITICAL: Missing CTR for reportable transaction\n   - HIGH: Late filing (>30 days)\n   - MEDIUM: Incomplete/inaccurate information\n   - LOW: Minor form errors\n9. Generate CTR compliance report",
  "composes_with": ["TRG.AUDIT.003", "DIR.AUDIT.003", "SUBJ.CTR.001"],
  "metadata": {
    "domain": "compliance-verification",
    "priority": 95,
    "version": "1.0.0",
    "regulatory_deadline": "15 calendar days from transaction",
    "estimated_time": "5-10 minutes per CTR review"
  }
}
```

---

## INST.CTR.002 - CTR Aggregation Analysis

```json
{
  "id": "INST.CTR.002",
  "type": "INSTRUCTION",
  "name": "CTR Aggregation Rule Analysis",
  "description": "Verify proper aggregation of related transactions",
  "content": "STEPS:\n1. Review all currency transactions for single business day\n2. Group transactions by customer (individual or business)\n3. Identify transactions conducted on behalf of same person\n4. Apply multiple transaction aggregation rules:\n   a. Same person conducting multiple transactions\n   b. Agent/representative acting on behalf of person\n   c. Related business entities\n   d. Structured transactions to avoid reporting\n5. Calculate aggregate totals for related transactions\n6. Determine if aggregated amount ≥$10,000\n7. Verify CTR filed for aggregated transactions ≥$10,000\n8. Check that all related transactions listed on single CTR\n9. Document aggregation logic and calculations\n10. Identify cases where aggregation not properly applied\n11. Flag potential structuring when aggregation reveals pattern",
  "composes_with": ["INST.CTR.001", "INST.STRUCT.001", "DIR.AUDIT.003"],
  "metadata": {
    "domain": "compliance-verification",
    "priority": 92,
    "version": "1.0.0",
    "estimated_time": "15-20 minutes per day analyzed"
  }
}
```

---

## INST.SAR.001 - SAR Decision Analysis

```json
{
  "id": "INST.SAR.001",
  "type": "INSTRUCTION",
  "name": "Suspicious Activity Report Decision Analysis",
  "description": "Evaluate appropriateness of SAR filing decisions",
  "content": "STEPS:\n1. Review all suspicious activity alerts/investigations\n2. For each investigation:\n   a. Alert/referral details\n   b. Investigation scope and procedures\n   c. Evidence gathered\n   d. Analysis performed\n   e. Decision made (file SAR vs. clear)\n   f. Decision rationale documented\n3. Evaluate investigation quality:\n   a. Sufficient information gathered\n   b. Appropriate sources consulted\n   c. Timeline reasonable\n   d. Analysis logical\n4. Review SAR filing decision:\n   a. Compare indicators to FinCEN SAR categories\n   b. Assess whether activity meets reporting threshold\n   c. Verify decision documented with clear rationale\n5. For filed SARs:\n   a. Verify filed within 30 days of initial detection\n   b. Check narrative quality and completeness\n   c. Verify supporting documentation attached\n   d. Confirm continuing activity monitoring established\n6. For cleared alerts:\n   a. Verify clearing rationale documented\n   b. Assess whether clearing decision appropriate\n   c. Identify any missed reportable activity\n7. Document SAR decision quality:\n   - Appropriate filings\n   - Missed reportable activity (false negatives)\n   - Questionable clearing decisions\n8. Generate SAR decision quality report",
  "composes_with": ["TRG.AUDIT.004", "DIR.AUDIT.004", "SUBJ.SAR.001"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 98,
    "version": "1.0.0",
    "regulatory_deadline": "30 calendar days from initial detection",
    "estimated_time": "20-45 minutes per investigation review"
  }
}
```

---

## INST.SAR.002 - SAR Narrative Quality Review

```json
{
  "id": "INST.SAR.002",
  "type": "INSTRUCTION",
  "name": "SAR Narrative Quality Review",
  "description": "Assess quality and completeness of SAR narratives",
  "content": "STEPS:\n1. Review SAR narrative section\n2. Check narrative includes five W's:\n   - WHO: Subject identification, relationship to institution\n   - WHAT: Suspicious activity description\n   - WHEN: Timeline of suspicious activity\n   - WHERE: Location/branches involved\n   - WHY: Why activity deemed suspicious\n3. Verify narrative clarity:\n   a. Written in clear, concise language\n   b. Chronological flow logical\n   c. Facts distinguished from suspicions\n   d. Technical jargon explained\n4. Check completeness:\n   a. All relevant transactions detailed\n   b. Dollar amounts and dates specific\n   c. Suspicious indicators explained\n   d. Investigation actions documented\n   e. External information sources noted\n5. Assess narrative usefulness for law enforcement:\n   a. Sufficient detail for follow-up investigation\n   b. Contact information provided\n   c. Relevant documentation referenced\n6. Identify narrative weaknesses:\n   - Vague descriptions\n   - Missing critical details\n   - Unclear suspicion basis\n   - Inadequate transaction detail\n7. Document narrative quality score (1-5 scale)\n8. Provide narrative improvement recommendations",
  "composes_with": ["INST.SAR.001", "DIR.AUDIT.004", "BP.SAR.001"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 90,
    "version": "1.0.0",
    "estimated_time": "10-15 minutes per SAR narrative"
  }
}
```

---

## INST.OFAC.001 - OFAC Screening Verification

```json
{
  "id": "INST.OFAC.001",
  "type": "INSTRUCTION",
  "name": "OFAC Screening Verification Procedure",
  "description": "Verify sanctions screening performed and documented",
  "content": "STEPS:\n1. Identify screening requirements:\n   a. Account opening screening (all new customers)\n   b. Transaction screening (wires, ACH, high-risk)\n   c. Periodic rescreening (at least annually)\n2. For account opening:\n   a. Verify screening performed before account opened\n   b. Check customer name screened against SDN list\n   c. Review beneficial owners screened (if legal entity)\n   d. Verify screening results documented\n3. For transactions:\n   a. Verify wire transfers screened (all parties)\n   b. Check originator and beneficiary screening\n   c. Review intermediary bank screening\n   d. Verify screening timestamp before transaction processed\n4. For periodic rescreening:\n   a. Verify all customers screened at least annually\n   b. Check rescreening date documented\n   c. Review results compared to previous screening\n5. Review screening matches:\n   a. Identify all potential matches (hits)\n   b. Verify each match investigated\n   c. Check false positive clearing documentation\n   d. Verify true match escalation to compliance officer\n6. For true matches (blocked parties):\n   a. Verify transaction/account blocked immediately\n   b. Check OFAC notification made within 10 days\n   c. Verify funds frozen and not released\n   d. Review blocking documentation completeness\n7. Document screening compliance:\n   - Screening frequency adequate\n   - Match investigation quality\n   - Blocking actions appropriate\n8. Identify screening deficiencies\n9. Generate OFAC compliance report",
  "composes_with": ["TRG.AUDIT.005", "DIR.AUDIT.005", "SUBJ.OFAC.001"],
  "metadata": {
    "domain": "sanctions-compliance",
    "priority": 99,
    "version": "1.0.0",
    "regulatory_deadline": "Before transaction processing",
    "estimated_time": "5-10 minutes per screening review"
  }
}
```

---

## INST.OFAC.002 - OFAC Match Resolution Review

```json
{
  "id": "INST.OFAC.002",
  "type": "INSTRUCTION",
  "name": "OFAC Match Resolution Quality Review",
  "description": "Assess quality of OFAC match investigation and resolution",
  "content": "STEPS:\n1. Review all OFAC screening matches/hits\n2. For each match:\n   a. Date/time of screening\n   b. Customer/transaction details\n   c. SDN entry that triggered match\n   d. Match score/percentage\n3. Evaluate investigation procedures:\n   a. Investigator qualifications\n   b. Information sources consulted\n   c. Comparison criteria used\n   d. Decision timeline (immediate for true match)\n4. Review false positive determinations:\n   a. Clear distinguishing information documented\n   b. Comparison logic sound\n   c. Decision maker authorized\n   d. Documentation sufficient for audit\n5. Review true match handling:\n   a. Immediate blocking action taken\n   b. Compliance officer notified immediately\n   c. OFAC reported within 10 days\n   d. Funds remained frozen\n   e. Customer notification handled appropriately\n6. Assess resolution quality:\n   - Appropriate decisions\n   - Adequate documentation\n   - Timely escalation\n   - Proper blocking procedures\n7. Identify resolution weaknesses:\n   - Delayed investigations\n   - Inadequate documentation\n   - Questionable clearing decisions\n   - Improper blocking procedures\n8. Generate match resolution quality report",
  "composes_with": ["INST.OFAC.001", "DIR.AUDIT.005", "VER.AUDIT.003"],
  "metadata": {
    "domain": "sanctions-compliance",
    "priority": 98,
    "version": "1.0.0",
    "estimated_time": "15-25 minutes per match review"
  }
}
```

---

## INST.BEN.001 - Beneficial Ownership Documentation Review

```json
{
  "id": "INST.BEN.001",
  "type": "INSTRUCTION",
  "name": "Beneficial Ownership Documentation Review",
  "description": "Verify beneficial ownership requirements met for legal entities",
  "content": "STEPS:\n1. Identify accounts requiring beneficial ownership:\n   a. Legal entity customers (corporations, LLCs, partnerships)\n   b. Opened after May 11, 2018 (compliance date)\n   c. Exclusions verified if claimed (publicly traded, government, etc.)\n2. Obtain Certification of Beneficial Owners form\n3. Verify form completeness:\n   a. Entity information complete\n   b. Control prong individual identified (if applicable)\n   c. Ownership prong individuals identified (25%+ owners)\n   d. Each beneficial owner's information complete:\n      - Name\n      - Date of birth\n      - Address\n      - Social Security Number or other ID\n   e. Certification signed and dated\n4. Verify beneficial owner information:\n   a. Identification verified for each beneficial owner\n   b. Verification method documented\n   c. ID documents copied and retained\n5. Check form obtained at account opening or within reasonable time\n6. For changes in beneficial ownership:\n   a. Verify change detected through monitoring\n   b. Check updated certification obtained\n   c. Verify new beneficial owners verified\n7. Review form retention (5 years after account closed)\n8. Document beneficial ownership compliance:\n   - Form obtained and complete\n   - All beneficial owners identified\n   - Verification performed\n   - Updates obtained when needed\n9. Identify deficiencies:\n   - Missing forms\n   - Incomplete information\n   - Unverified beneficial owners\n   - Outdated information\n10. Generate beneficial ownership compliance report",
  "composes_with": ["TRG.AUDIT.006", "DIR.AUDIT.006", "SUBJ.BEN.001"],
  "metadata": {
    "domain": "customer-due-diligence",
    "priority": 94,
    "version": "1.0.0",
    "regulatory_basis": "31 CFR 1010.230",
    "estimated_time": "10-15 minutes per legal entity account"
  }
}
```

---

## INST.BEN.002 - Beneficial Ownership Update Monitoring

```json
{
  "id": "INST.BEN.002",
  "type": "INSTRUCTION",
  "name": "Beneficial Ownership Update Monitoring",
  "description": "Verify procedures to detect and update beneficial ownership changes",
  "content": "STEPS:\n1. Review beneficial ownership update procedures\n2. Check monitoring triggers:\n   a. Customer notification of ownership change\n   b. Periodic customer outreach (at KYC refresh)\n   c. Public records review (for corporations)\n   d. Suspicious activity indicators\n   e. Significant transaction pattern changes\n3. Verify update process:\n   a. Procedure to request updated certification\n   b. Timeline for obtaining updated information\n   c. Verification of new beneficial owners\n   d. Documentation of changes\n4. Review sample of ownership changes:\n   a. Change detection method\n   b. Time from detection to update request\n   c. Time to obtain updated certification\n   d. New beneficial owner verification\n5. Assess update frequency:\n   a. Periodic refresh schedule (typically 3-5 years)\n   b. Event-driven updates when changes detected\n   c. Risk-based update frequency (more frequent for high-risk)\n6. Document update monitoring effectiveness:\n   - Detection mechanisms working\n   - Updates obtained timely\n   - New beneficial owners verified\n   - Documentation complete\n7. Identify monitoring gaps:\n   - Changes not detected\n   - Delayed updates\n   - Incomplete information\n8. Generate beneficial ownership monitoring report",
  "composes_with": ["INST.BEN.001", "DIR.AUDIT.006", "SUBJ.BEN.001"],
  "metadata": {
    "domain": "customer-due-diligence",
    "priority": 88,
    "version": "1.0.0",
    "estimated_time": "20-30 minutes to review monitoring process"
  }
}
```

---

## INST.STRUCT.001 - Structuring Pattern Detection

```json
{
  "id": "INST.STRUCT.001",
  "type": "INSTRUCTION",
  "name": "Structuring Pattern Detection Procedure",
  "description": "Identify transaction patterns suggesting CTR avoidance",
  "content": "STEPS:\n1. Analyze transactions for structuring indicators:\n   a. Multiple transactions just under $10,000\n   b. Transactions in amounts like $9,000, $9,500, $9,900\n   c. Split deposits/withdrawals same day\n   d. Multiple locations same day\n   e. Transactions at multiple branches\n   f. Pattern over multiple days\n2. Calculate transaction frequency and timing:\n   a. Number of just-under-threshold transactions\n   b. Time intervals between transactions\n   c. Location patterns\n   d. Seasonal or regular patterns\n3. Assess relationship to $10,000 threshold:\n   a. Calculate aggregate amounts\n   b. Identify if aggregation crosses threshold\n   c. Determine if pattern appears deliberate\n4. Review customer explanations:\n   a. Business justification provided\n   b. Source of funds documented\n   c. Purpose of transactions explained\n   d. Consistency with customer profile\n5. Evaluate customer behavior:\n   a. Customer knowledge of reporting thresholds\n   b. Customer questions about reporting\n   c. Customer requests to split transactions\n   d. Evasive responses to questions\n6. Cross-reference related accounts:\n   a. Related business accounts\n   b. Personal accounts of business owners\n   c. Family member accounts\n   d. Employee accounts\n7. Calculate structuring risk score:\n   - High (90-100): Clear pattern, deliberate avoidance\n   - Medium (60-89): Suspicious pattern, unclear intent\n   - Low (0-59): Coincidental, business justified\n8. For high-risk structuring:\n   a. Flag for SAR filing\n   b. Document pattern with evidence\n   c. Prepare SAR narrative\n9. Generate structuring analysis report",
  "composes_with": ["TRG.AUDIT.007", "DIR.AUDIT.007", "INST.SAR.001"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 97,
    "version": "1.0.0",
    "estimated_time": "25-40 minutes per case analyzed"
  }
}
```

---

## INST.STRUCT.002 - Structuring Investigation Procedure

```json
{
  "id": "INST.STRUCT.002",
  "type": "INSTRUCTION",
  "name": "Structuring Investigation Procedure",
  "description": "Conduct thorough investigation of suspected structuring",
  "content": "STEPS:\n1. Gather all relevant transaction data:\n   a. All transactions 30-90 days before/after suspected structuring\n   b. Related account transactions\n   c. Historical transaction patterns\n2. Interview customer (if appropriate and safe):\n   a. Ask about transaction purposes\n   b. Inquire about source of funds\n   c. Request supporting documentation\n   d. Note customer demeanor and responses\n   e. Document interview carefully\n3. Review customer communications:\n   a. Emails about transactions\n   b. Instructions to staff\n   c. Questions about reporting requirements\n4. Consult external information:\n   a. Public records about customer business\n   b. Industry information\n   c. News about customer\n5. Analyze evidence:\n   a. Pattern consistency\n   b. Business justification credibility\n   c. Customer knowledge of thresholds\n   d. Deliberateness indicators\n6. Document investigation:\n   a. Information sources consulted\n   b. Customer statements\n   c. Supporting documentation obtained\n   d. Analysis and conclusions\n7. Make SAR filing determination:\n   a. If deliberate structuring evident: FILE SAR\n   b. If pattern unclear: continue monitoring, document decision\n   c. If business justified: clear, document rationale\n8. For SAR filing:\n   a. Prepare comprehensive narrative\n   b. Attach supporting documentation\n   c. File within 30 days of initial detection\n   d. Establish ongoing monitoring\n9. Generate investigation report regardless of outcome",
  "composes_with": ["INST.STRUCT.001", "INST.SAR.001", "DIR.AUDIT.007"],
  "metadata": {
    "domain": "suspicious-activity",
    "priority": 96,
    "version": "1.0.0",
    "estimated_time": "2-4 hours per investigation"
  }
}
```

---

## INST.RISK.001 - Customer Risk Profile Assessment

```json
{
  "id": "INST.RISK.001",
  "type": "INSTRUCTION",
  "name": "Customer Risk Profile Assessment",
  "description": "Evaluate and score customer ML/TF risk",
  "content": "STEPS:\n1. Gather customer information:\n   a. Customer type (individual, business, entity type)\n   b. Industry/occupation\n   c. Products and services used\n   d. Geographic locations\n   e. Expected activity levels\n   f. Source of wealth/funds\n2. Score customer type risk (0-10):\n   - Individual consumer: 2\n   - Small business: 5\n   - Large corporation: 5\n   - Money service business: 8\n   - Check casher: 8\n   - Money transmitter: 9\n   - Cannabis-related business: 9\n   - Cryptocurrency exchange: 9\n   - PEP (Politically Exposed Person): 9\n3. Score geographic risk (0-10):\n   - Domestic only (US): 2\n   - Canada/Western Europe: 3\n   - Eastern Europe: 6\n   - Latin America: 7\n   - Middle East: 8\n   - High-risk countries (FATF list): 9-10\n4. Score product/service risk (0-10):\n   - Savings/checking only: 2\n   - Consumer loans: 3\n   - Commercial accounts: 5\n   - Wire transfer services: 7\n   - Cash-intensive services: 8\n   - International wires: 8\n   - Trade finance: 8\n   - Correspondent banking: 9\n   - Private banking: 9\n5. Score transaction activity risk (0-10):\n   - Low volume, low complexity: 2\n   - Moderate volume: 5\n   - High volume: 7\n   - High volume + cash intensive: 9\n   - Unusual patterns: 8-10\n6. Calculate composite risk score:\n   Total = (Customer Type × 35%) + (Geographic × 25%) + (Products × 25%) + (Activity × 15%)\n7. Assign overall risk rating:\n   - Low: 0-30\n   - Medium: 31-60\n   - High: 61-100\n8. Determine required controls:\n   Low: Standard CDD, annual KYC refresh, routine monitoring\n   Medium: Enhanced CDD, semi-annual refresh, enhanced monitoring\n   High: Intensive CDD, quarterly refresh, continuous monitoring, management approval\n9. Document risk assessment with supporting rationale\n10. Generate risk profile report",
  "composes_with": ["TRG.AUDIT.008", "DIR.AUDIT.008", "SUBJ.RISK.001"],
  "metadata": {
    "domain": "risk-assessment",
    "priority": 93,
    "version": "1.0.0",
    "estimated_time": "15-25 minutes per customer"
  }
}
```

---

**[Continuing in next file - remaining 30+ instruction blocks...]**

This is Part 2 of the complete MOLT blocks library. Creating remaining instruction blocks, then subjects, primary values, philosophies, blueprints, and verifications in subsequent files.
