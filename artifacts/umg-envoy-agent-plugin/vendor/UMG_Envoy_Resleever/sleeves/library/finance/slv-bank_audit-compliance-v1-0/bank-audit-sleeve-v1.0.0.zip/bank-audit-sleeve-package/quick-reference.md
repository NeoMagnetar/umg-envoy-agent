# QUICK REFERENCE GUIDE
## Bank Account Compliance Auditor

**One-Page Cheat Sheet for Daily Use**

---

## SEVERITY LEVELS

| Level | When to Use | Example |
|-------|-------------|---------|
| **CRITICAL** | Regulatory violation, material impact | Missing CTR for $50k cash transaction |
| **HIGH** | Policy violation, significant risk | SAR filed 45 days late |
| **MEDIUM** | Process gap, documentation issue | Incomplete beneficial ownership form |
| **LOW** | Minor deviation | Transaction notes could be more detailed |
| **INFO** | Observation, suggestion | Process efficiency opportunity |

---

## REGULATORY THRESHOLDS

| Requirement | Threshold | Deadline | Regulation |
|-------------|-----------|----------|------------|
| **CTR** | $10,000 cash (single/aggregate) | 15 days | 31 CFR 1020.310 |
| **SAR** | $5k+ (insider) / $25k+ (other) | 30 days | 31 CFR 1020.320 |
| **OFAC** | All customers/transactions | Immediate | OFAC SDN |
| **Beneficial Ownership** | 25% ownership OR control | At opening | 31 CFR 1010.230 |
| **CIP** | All new accounts | At opening | 31 CFR 1020.220 |

---

## QUICK COMMANDS

**New Account Audit:**
```
Audit this account:
- Account #: [number]
- Type: [checking/savings/business]
- Opened: [date]
- Customer: [name/entity]

[Attach account opening docs]
```

**Transaction Review:**
```
Review these transactions for compliance:

[Attach: transactions.csv with columns: Date, Amount, Type, Description]
```

**CTR Verification:**
```
Verify CTR compliance for [month/year]:

[Attach: cash-transactions.csv]
[Attach: filed-ctrs.csv]
```

**SAR Quality Check:**
```
Review this SAR filing:

[Attach: investigation-notes.pdf]
[Attach: sar-narrative.txt]
```

---

## COMMON FINDINGS

### Account Opening

✗ **Missing CIP certification**
- Severity: HIGH
- Fix: Obtain certification, verify ID retroactively

✗ **No beneficial ownership form (legal entity)**
- Severity: HIGH  
- Fix: Obtain FinCEN form immediately

✗ **Risk rating not assigned**
- Severity: MEDIUM
- Fix: Complete risk assessment, document

### Transactions

✗ **Structuring pattern** (multiple $9k deposits)
- Severity: HIGH
- Fix: File SAR, enhance monitoring

✗ **Missing CTR** (cash >$10k)
- Severity: CRITICAL
- Fix: File CTR immediately, document reason for delay

✗ **Late CTR filing** (>15 days)
- Severity: HIGH
- Fix: File if not yet filed, improve procedures

### Compliance

✗ **No OFAC screening at opening**
- Severity: CRITICAL
- Fix: Screen immediately, document finding

✗ **SAR not filed** (clear indicators present)
- Severity: CRITICAL
- Fix: File SAR immediately if within 60 days

✗ **Incomplete SAR narrative**
- Severity: MEDIUM
- Fix: Amend SAR with complete information

---

## NEOSTACK QUICK REFERENCE

| Stack | Use When | Output |
|-------|----------|--------|
| **S.01 Account Verification** | New account review, KYC audit | Compliance scorecard |
| **S.02 Transaction Analysis** | Transaction monitoring, pattern detection | Transaction audit report |
| **S.03 Compliance Verification** | Regulatory check, exam prep | Compliance status report |
| **S.04 Risk Assessment** | Risk rating validation | Risk profile |
| **S.05 Suspicious Activity** | SAR review, alert investigation | SAR quality report |
| **S.06 Documentation** | All audits | Audit reports |
| **S.07 Quality Assurance** | QA review, peer review | QA validation |

---

## DECISION TREES

### Should I File a SAR?

```
Is there suspicious activity?
├─ YES → Did we investigate?
│         ├─ YES → Does it meet SAR threshold?
│         │        ├─ YES → FILE SAR within 30 days
│         │        └─ NO → Document decision, continue monitoring
│         └─ NO → INVESTIGATE first, then reassess
└─ NO → Continue routine monitoring
```

### Is CTR Required?

```
Is it a currency transaction?
├─ YES → Is amount ≥$10,000 (single or aggregate)?
│         ├─ YES → Is customer exempt?
│         │        ├─ YES → Verify exemption valid → No CTR
│         │        └─ NO → FILE CTR within 15 days
│         └─ NO → No CTR required
└─ NO → No CTR required (not currency)
```

---

## OUTPUT TEMPLATES

**Finding:**
```
FINDING ID: AUDIT-2026-03-20-001
SEVERITY: HIGH
CATEGORY: Compliance

DESCRIPTION: Missing CTR for cash deposit

EVIDENCE: $15,000 cash deposit on 2026-02-15, 
no CTR filed as of 2026-03-20 (33 days late)

REGULATORY REFERENCE: 31 CFR 1020.310

RECOMMENDATION: File CTR immediately, 
review filing procedures
```

**Risk Score:**
```
CUSTOMER RISK PROFILE
Type: Money Service Business (8/10)
Geography: International wires (7/10)
Activity: High cash volume (8/10)

TOTAL: 77/100 (HIGH RISK)

MONITORING: Quarterly KYC refresh, 
continuous transaction monitoring, 
management approval required
```

---

## CONTACTS & RESOURCES

**Regulatory Resources:**
- FinCEN: https://www.fincen.gov
- FFIEC BSA/AML Manual: https://bsaaml.ffiec.gov
- OFAC SDN List: https://sanctionssearch.ofac.treas.gov

**Internal Escalation:**
- Critical findings → Compliance Officer (immediate)
- High findings → Audit Manager (24 hours)
- Medium/Low → Include in routine reporting

**Documentation:**
- Full specification: SLEEVE_SPECIFICATION.md
- Deployment guide: OPENCLAW_DEPLOYMENT.md
- MOLT blocks: MOLT_BLOCKS_COMPLETE.md

---

## TIPS & BEST PRACTICES

✓ **Always cite evidence** - "Based on transaction dated..." not "Transaction seems suspicious"

✓ **Be specific** - "$15,000 on 2026-02-15" not "Large amount recently"

✓ **State uncertainty** - "REQUIRES VERIFICATION: Unable to confirm..." when unsure

✓ **Document everything** - Even "no issues found" should be documented

✓ **Redact PII** - Use "Account #****1234" not full account numbers

✓ **Assign severity consistently** - Use the matrix above

✓ **Provide actionable recommendations** - "File CTR within 24 hours" not "Improve compliance"

✓ **Reference regulations** - Cite specific CFR sections

✓ **Maintain objectivity** - Facts and evidence, not assumptions

✓ **Follow up** - Track remediation, verify corrections

---

**Quick Start:** `openclaw --config bank-auditor-config.json`

**Help:** See OPENCLAW_DEPLOYMENT.md for detailed instructions
