# Idaho Grant Finder - UMG Sleeve
## Version 1.0.0

**Complete AI-assisted grant research system for Idaho residents, nonprofits, businesses, and government entities.**

---

## QUICK START

**5-Minute Setup with OpenClaw:**
```bash
# Copy system prompt to OpenClaw
cp system-prompt.txt ~/.openclaw/prompts/idaho-grants.txt

# Start using immediately
openclaw --prompt idaho-grants.txt

# Or in OpenClaw config:
# "system_prompt_file": "prompts/idaho-grants.txt"
```

**What You Get:**
- 8 specialized grant research areas (NeoStacks)
- 48 distinct grant finding functions (NeoBlocks)
- 184 atomic procedures (MOLT blocks)
- Complete Idaho grant landscape coverage
- Application support and compliance guidance

---

## OVERVIEW

This UMG sleeve transforms AI assistants into Idaho grant research specialists, providing systematic procedures for:

**Federal Grant Research**
- Grants.gov comprehensive searching
- USDA Rural Development programs (Idaho focus)
- Federal agency direct programs
- Regional and nationwide opportunities

**Idaho State Grant Research**
- Department of Commerce grants
- Health & Welfare grants
- Education grants
- All state agency programs

**Local Grant Research**
- County and municipal grants
- Regional economic development
- Community foundation grants
- Tribal programs

**Foundation Grant Research**
- Idaho Community Foundation
- Corporate foundations (Simplot, Albertsons, Micron, Blue Cross)
- National foundations accepting Idaho applicants

**Complete Application Support**
- Eligibility assessment
- Application strategy
- Budget development
- Deadline management
- Compliance guidance

---

## CORE PRINCIPLES (Always Active)

1. **Accuracy Above All Else** - Verified information only
2. **Deadline Awareness is Critical** - Time-sensitive prioritization
3. **Idaho-Specific Focus** - Geographic eligibility first
4. **Complete Information Always** - No incomplete grant listings
5. **Eligibility Verification First** - Pre-qualify before recommending
6. **Application Support and Strategy** - Full process assistance
7. **Compliance and Reporting Awareness** - Obligations explained upfront
8. **Continuous Monitoring and Updates** - Currency is critical

---

## TYPICAL USE CASES

### Finding Federal Grants for Rural Idaho Nonprofit
```
YOU: I'm a 501(c)(3) nonprofit in rural Idaho (Challis, population 1,000). 
We need funding for a new community center. What federal grants are available?

AGENT: [Activates Federal Grant Research + Eligibility Assessment]

FEDERAL GRANT OPPORTUNITIES FOR RURAL IDAHO NONPROFIT

Location: Challis, ID (Population 1,000) - ✓ USDA RURAL ELIGIBLE

=== TOP RECOMMENDATIONS ===

1. USDA Community Facilities Direct Loan & Grant Program
   Award Range: Up to 75% grant, 25% loan (combined $500K typical)
   Deadline: ROLLING (apply anytime)
   Eligibility: ✓ 501(c)(3) in community <20,000
   Match: 25% (can be in-kind or loan portion)
   Contact: Idaho USDA RD, (208) 378-5623
   
   WHY PERFECT FIT: Community centers are specifically eligible. Rural 
   Idaho is prime territory. Rolling deadline means apply when ready.
   
   TIMELINE:
   - Week 1-2: Contact USDA local office, begin pre-application
   - Week 3-6: Prepare full application
   - Submit when complete
   
2. Department of Commerce - EDA Public Works
   Award Range: $100,000 - $3,000,000
   Deadline: [Current fiscal year competition - CHECK WITH EDA]
   ...

[Provides 3-5 specific, vetted opportunities with complete information]
```

### Foundation Grant Search for Boise Education Nonprofit
```
YOU: We're a 501(c)(3) in Boise working on STEM education for 
underserved youth. Looking for $10,000 - $50,000 grants.

AGENT: [Activates Foundation Grant Research + Idaho State Grants]

FOUNDATION GRANT OPPORTUNITIES - BOISE STEM EDUCATION

=== IDAHO-BASED FOUNDATIONS ===

1. Idaho Community Foundation - Education Fund
   Award Range: $5,000 - $25,000 (typical)
   Deadline: Varies by fund (Ada County Fund: April 15, 45 days remaining)
   Application: Letter of intent first
   Contact: (208) 342-3535, [email protected]
   
2. Micron Technology Foundation
   Award Range: $10,000 - $100,000 (STEM focus)
   Deadline: ROLLING
   Strong fit: STEM education in Boise area (Micron headquarters)
   Application: Online portal
   
3. Blue Cross of Idaho Foundation for Health
   Award Range: $10,000 - $50,000
   Deadline: September (annual cycle)
   Fit: If STEM education has health/wellness component
   
=== NATIONAL FOUNDATIONS (ACCEPTING IDAHO) ===

4. Toshiba America Foundation
   STEM education grants: $5,000 - $15,000
   Deadline: Grades K-5 (May 1), Grades 6-12 (Oct 1)
   ...

[Complete listings with contact info and application guidance]
```

### Application Support
```
YOU: I need help writing the narrative for the USDA Community 
Facilities grant. What should I include?

AGENT: [Activates Application Strategy & Writing Support]

USDA COMMUNITY FACILITIES NARRATIVE STRUCTURE

SECTION 1: COMMUNITY NEED (2-3 pages)
- Describe Challis community demographics
- Current facility deficiencies/gaps
- Community input/needs assessment data
- How lack of community center impacts residents
- Special populations served (youth, seniors, etc.)

KEY QUESTIONS TO ANSWER:
- What problem does this solve?
- Who is affected?
- What evidence supports the need?

SECTION 2: PROJECT DESCRIPTION (3-4 pages)
...

[Provides complete outline, writing tips, and examples]
```

---

## GRANT SOURCES COVERED

**Federal Sources:**
- Grants.gov (all 26 federal agencies)
- USDA Rural Development (major focus for rural Idaho)
- Department of Commerce (EDA)
- HHS, DOE, EPA, NEA, NEH, and more

**Idaho State Sources:**
- Department of Commerce (CDBG, IGEM, Opportunity Fund)
- Health & Welfare (CSBG, substance abuse, mental health)
- Department of Education (charter schools, STEM, professional development)
- Transportation Department (Safe Routes, transit)
- Environmental Quality (water, air quality, waste)

**Local Sources:**
- All Idaho counties
- Major cities (Boise, Meridian, Nampa, Idaho Falls, Pocatello, Coeur d'Alene)
- Regional economic development organizations

**Foundation Sources:**
- Idaho Community Foundation (statewide + regional funds)
- J.R. Simplot Company Foundation
- Albertsons Companies Foundation
- Micron Technology Foundation
- Blue Cross of Idaho Foundation for Health
- National foundations accepting Idaho applicants

---

## WHAT THIS SLEEVE COVERS

### ✅ Included Capabilities

**Grant Research:**
- Federal grant database searching
- Idaho state agency grants
- County and municipal grants
- Foundation and corporate grants
- Tribal programs
- Multi-source comprehensive searches

**Eligibility Assessment:**
- 501(c)(3) vs other nonprofit status
- Geographic eligibility (Idaho-specific)
- Project type alignment
- Budget range matching
- Organizational capacity assessment

**Application Support:**
- Needs statement development
- Logic model creation
- Budget development and templates
- Narrative writing guidance
- Letters of support coordination
- Application timeline creation

**Deadline Management:**
- Calendar and alerts
- Multi-grant tracking
- Pre-application deadlines
- Letter of intent deadlines
- Rolling vs fixed deadlines

**Compliance Guidance:**
- Grant agreement review
- Reporting requirements
- Audit preparation
- Match/cost-share tracking
- Financial management
- Closeout procedures

### ❌ What This Sleeve Doesn't Do

- Write complete grant applications (provides guidance and support)
- Guarantee grant awards (provides best opportunities and strategy)
- Submit applications (assists with preparation)
- Provide legal advice (suggests consulting attorney when needed)
- Replace grant writer (assists experienced and novice users)

---

## DEPLOYMENT OPTIONS

### Option 1: OpenClaw (Recommended)
```bash
# Install OpenClaw if not already installed
curl -fsSL https://openclaw.ai/install.sh | bash

# Copy system prompt
cp system-prompt.txt ~/.openclaw/prompts/idaho-grants.txt

# Option A: Use in conversation
openclaw --prompt idaho-grants.txt

# Option B: Set in config
# Edit ~/.openclaw/openclaw.json:
# "system_prompt_file": "prompts/idaho-grants.txt"

# Start finding grants
> I'm a nonprofit in Boise looking for education grants
> Find USDA grants for rural Idaho community development
> What Idaho state grants are available for health programs?
```

### Option 2: Claude.ai
1. Open Claude.ai
2. Paste entire `system-prompt.txt` as first message
3. Start requesting grant research

### Option 3: ChatGPT
1. Settings → Custom Instructions
2. Paste system prompt in "How would you like ChatGPT to respond"
3. Start new chat for grant finding

---

## EXAMPLE OUTPUTS

**Grant Search Result:**
```
GRANT OPPORTUNITIES FOR NONPROFIT IN RURAL IDAHO

1. USDA Community Facilities Direct Loan & Grant
   Award: Up to $500,000 (75% grant, 25% loan typical)
   Deadline: ROLLING ⚠️ (apply when ready)
   Eligibility: ✓ 501(c)(3), community <20,000
   Match: 25% (loan portion or other match)
   Link: https://www.rd.usda.gov/programs-services/...
   Contact: Idaho USDA RD, (208) 378-5623
   
   TIMELINE:
   - Week 1-2: Pre-application with local USDA office
   - Week 3-6: Full application preparation
   - Week 7+: Submit when complete
   
   WHY RECOMMENDED: Perfect fit for rural community facilities.
   Idaho is 95% rural - prime USDA territory.
```

**Eligibility Assessment:**
```
ELIGIBILITY ASSESSMENT

Grant: Idaho Department of Commerce CDBG
Organization: Your Idaho Nonprofit

✓ ELIGIBLE CRITERIA MET:
- Idaho location: YES (Boise, ID)
- 501(c)(3) status: YES
- Serves low-moderate income: YES
- Infrastructure project: YES

⚠️ POTENTIAL CHALLENGES:
- CDBG requires extensive environmental review
- May need city/county as applicant (nonprofit as beneficiary)

RECOMMENDATION: MODERATE FIT - Work with City of Boise as applicant

NEXT STEPS:
1. Contact Boise Community Development Dept
2. Explore city sponsorship
3. Prepare community needs data
```

---

## GRANT AMOUNT GUIDELINES

**Federal Grants:**
- Small: $10,000 - $100,000
- Medium: $100,000 - $500,000
- Large: $500,000 - $5,000,000+
- Timeline: 60-120 days application to deadline
- Compliance: High (federal regulations)

**Idaho State Grants:**
- Small: $5,000 - $50,000
- Medium: $50,000 - $250,000
- Large: $250,000 - $1,000,000
- Timeline: 30-90 days
- Compliance: Moderate

**Foundation Grants:**
- Small: $1,000 - $10,000
- Medium: $10,000 - $50,000
- Large: $50,000 - $250,000
- Timeline: 30-60 days
- Compliance: Light to moderate

**Local Grants:**
- Typically: $1,000 - $25,000
- Timeline: 30-60 days
- Compliance: Light

---

## TYPICAL WORKFLOWS

### Complete Grant Search Workflow (30-60 min)
1. Clarify user profile (5 min)
2. Search federal sources (10-15 min)
3. Search Idaho state sources (10 min)
4. Search local/foundation sources (10-15 min)
5. Verify eligibility (5-10 min)
6. Present prioritized results (5 min)

### Application Support Workflow (varies)
1. Assess grant requirements (15 min)
2. Develop application outline (30 min)
3. Provide narrative guidance (30-60 min)
4. Create budget template (30 min)
5. Develop logic model (30 min)
6. Review draft materials (30-60 min)

### Deadline Management (ongoing)
1. Create application calendar
2. Track multiple grants
3. Alert on upcoming deadlines
4. Monitor for extensions/changes

---

## IDAHO-SPECIFIC ADVANTAGES

**Geographic Benefits:**
- 95% rural = extensive USDA eligibility
- Low population = less competitive local grants
- Region 10 federal programs
- State programs for small communities

**Key Idaho Contacts:**
- Idaho Community Foundation: (208) 342-3535
- Idaho Dept of Commerce: (208) 334-2470
- USDA Rural Development Idaho: (208) 378-5623
- Idaho Dept of Health & Welfare: (208) 334-5500

---

## PACKAGE CONTENTS

**Core Files:**
- `system-prompt.txt` - Ready-to-use AI system prompt (33KB)
- `COMPLETE_IDAHO_GRANTS_SLEEVE_STRUCTURE.md` - Full technical spec
- `README.md` - This file

**Deployment:**
- `openclaw-config.json` - OpenClaw configuration template
- `quick-reference.md` - One-page cheat sheet

**Reference:**
- `CHANGELOG.md` - Version history

---

## SUPPORT & UPDATES

**Official Idaho Grant Resources:**
- Idaho Dept of Commerce: commerce.idaho.gov
- Grants.gov: www.grants.gov
- Idaho Community Foundation: idahocf.org
- USDA Rural Development: rd.usda.gov/id

**Version:** 1.0.0  
**Release Date:** 2026-03-29  
**Framework:** Universal Modular Generation (UMG)  
**Status:** Production Ready

---

**Get Started:** Open `quick-reference.md` for a one-page guide, or deploy with OpenClaw for immediate grant searching capability.

**Ready to find funding opportunities across Idaho with systematic AI assistance.**
