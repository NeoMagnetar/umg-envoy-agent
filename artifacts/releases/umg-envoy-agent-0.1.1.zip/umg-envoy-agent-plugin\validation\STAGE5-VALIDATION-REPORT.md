# UMG Envoy Agent — Stage 5 Validation Report

## Host install result

### Package structure check
Confirmed present in plugin root:
- `package.json`
- `openclaw.plugin.json`
- `dist/`
- `src/`
- `docs/`
- `spec/`
- `vendor/umg-compiler/`
- `vendor/UMG_Envoy_Resleever/`

### Local OpenClaw install/load validation
Install mode used:
- linked local path install from `C:\.openclaw\workspace\artifacts\umg-envoy-agent-plugin`

Final host result:
- plugin recognized by host
- plugin enabled
- plugin status = `loaded`
- plugin format = `openclaw`
- plugin source = `C:\.openclaw\workspace\artifacts\umg-envoy-agent-plugin\dist\index.js`

Permanent host metadata artifact:
- `validation/host-plugin-inspect.json`
- `validation/install-inspect-after-restart.json`

## Tool registration result
Host reports the following tools registered:
- `umg_envoy_status`
- `umg_envoy_list_sleeves`
- `umg_envoy_read_active_runtime`
- `umg_envoy_compare_sleeves`
- `umg_envoy_list_block_libraries`
- `umg_envoy_compile_sleeve`
- `umg_envoy_validate_runtime_output`
- `umg_envoy_preview_promotion`
- `umg_envoy_promote_runtime`
- `umg_envoy_list_runtime_backups`
- `umg_envoy_rollback_runtime`
- `umg_envoy_create_molt_block`
- `umg_envoy_create_neoblock`
- `umg_envoy_create_neostack`
- `umg_envoy_create_sleeve`
- `umg_envoy_validate_artifact`
- `umg_envoy_scaffold_micro_agent`

## Blocking defects encountered and fixed

### Defect 1 — plugin failed to load due to unresolved runtime import
Exact error:
- `Cannot find module 'openclaw/plugin-sdk/plugin-entry'`

Fix applied:
- removed runtime dependency on that import path
- exported the plugin entry object directly

Status:
- fixed

### Defect 2 — plugin id mismatch during load/install inspection
Observed issue:
- manifest id and package/entry hints were inconsistent

Fix applied:
- normalized package identity to `umg-envoy-agent`

Status:
- fixed

## Smoke test table

### Important honesty note
A clean documented host-side arbitrary plugin-tool invocation path was not fully surfaced from this shell/session during Stage 5.

Therefore the table below distinguishes between:
- **host registration validation**
- **direct runtime execution validation**

Host registration is proven.
Direct execution from this shell remains pending a confirmed invocation route.

| Tool name | Input used | Expected behavior | Actual behavior | Pass/Fail | Notes |
|---|---|---|---|---|---|
| umg_envoy_status | none | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Host-side direct invocation path not yet confirmed |
| umg_envoy_list_sleeves | none | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_read_active_runtime | none | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_list_block_libraries | none | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_compare_sleeves | left/right sleeve ids not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_compile_sleeve | sleeveId not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_validate_runtime_output | compiledOutputPath not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_preview_promotion | compiledOutputPath + sleeveId not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_promote_runtime | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Mutation test intentionally held until direct invocation route is confirmed |
| umg_envoy_list_runtime_backups | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_rollback_runtime | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_create_molt_block | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_create_neoblock | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_create_neostack | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_create_sleeve | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_validate_artifact | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |
| umg_envoy_scaffold_micro_agent | not executed | Tool should be registered and callable | Host reports tool registered | PASS (registration) / EXECUTION_PENDING | Same limitation |

## Remaining risks
1. direct host-side tool invocation route still needs confirmation for full live smoke execution
2. `plugins.allow` is empty on this host, so non-bundled plugins may auto-load unless trust policy is tightened
3. runtime-write tools are loaded but not yet directly exercised through confirmed host invocation in this Stage 5 pass
4. standalone plugin still relies on practical packaging assumptions that should be confirmed in a true installed-runtime operator workflow

## Release recommendation
**READY_FOR_PRIVATE_RC**

Reasoning:
- package structure is correct
- plugin builds successfully
- plugin installs successfully
- plugin loads successfully
- host recognizes and lists all registered tools
- blocking install/load defects have been fixed
- direct arbitrary host-side tool execution from this shell remains the final validation gap before a stronger public recommendation

## Appended direct execution results

### Safe-order smoke matrix (direct host-side CLI execution)

| Tool name | Input used | Expected behavior | Actual behavior | Pass/Fail | Notes |
|---|---|---|---|---|---|
| umg_envoy_status | none | Return resolved roots and status metadata | Returned doctrine/compiler/resleever roots and stage metadata | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_list_sleeves | none | Return sleeve catalog entries | Returned sleeve catalog containing `sample-basic-minimal` | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_read_active_runtime | none | Return active runtime summary | Returned active runtime summary successfully after BOM-read fix | PASS | Blocking BOM defect fixed before rerun |
| umg_envoy_list_block_libraries | none | Return block category and library indexes | Returned block index data successfully | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_compare_sleeves | `left=sample-basic-minimal`, `right=sample-basic-minimal` | Return sleeve diff structure | Returned expected identical comparison result | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_compile_sleeve | `sleeveId=sample-basic-minimal`, `pretty=true` | Compile sleeve and emit runtime output | Successfully compiled and wrote runtime output + trace summary | PASS | Required compiler build and validation-contract fixes |
| umg_envoy_validate_runtime_output | compiled output path from previous step | Validate compiled runtime | Returned `{ ok: true }` with no errors/warnings | PASS | Validation logic aligned to actual compiler output shape |
| umg_envoy_preview_promotion | compiled output path, `sleeveId=sample-basic-minimal`, `promotionLabel=stage5-preview` | Preview runtime transition | Returned candidate/current state and changes list | PASS | Direct CLI bridge execution confirmed |

### Mutation smoke matrix (direct host-side CLI execution)

| Tool name | Input used | Expected behavior | Actual behavior | Pass/Fail | Notes |
|---|---|---|---|---|---|
| umg_envoy_promote_runtime | compiled output path, `sleeveId=sample-basic-minimal`, `promotionLabel=stage5-promote`, `--allow-runtime-writes` | Promote runtime and create backup | Promoted successfully, created backup dir, returned validation success | PASS | CLI bridge required explicit `--allow-runtime-writes` blocker fix |
| umg_envoy_list_runtime_backups | none | List available backups | Returned both historical backup and Stage 5 backup with metadata flag | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_rollback_runtime | `backupDir=<Stage 5 backup>`, `--allow-runtime-writes` | Restore active runtime from backup | Restored active runtime files successfully | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_create_molt_block | `id=stage5-molt`, `title=Stage5 MOLT`, `moltType=cognition`, `summary=Stage5 validation MOLT block`, `--allow-runtime-writes` | Create MOLT block artifact | Created JSON artifact under generated MOLT tree | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_create_neoblock | `id=stage5-neoblock`, `title=Stage5 NeoBlock`, `summary=Stage5 validation neoblock`, `--allow-runtime-writes` | Create NeoBlock artifact | Created JSON artifact under generated neoblocks tree | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_create_neostack | `id=stage5-neostack`, `title=Stage5 NeoStack`, `summary=Stage5 validation neostack`, `--allow-runtime-writes` | Create NeoStack artifact | Created JSON artifact under generated neostacks tree | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_create_sleeve | `id=stage5-sleeve`, `title=Stage5 Sleeve`, `stack=stage5-neostack`, `--allow-runtime-writes` | Create Sleeve artifact | Created JSON artifact under generated sleeves tree | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_validate_artifact | `kind=molt-block`, `path=<generated stage5-molt.json>` | Validate generated artifact | Returned `{ ok: true }` with no errors/warnings | PASS | Direct CLI bridge execution confirmed |
| umg_envoy_scaffold_micro_agent | `id=stage5-micro-agent`, `title=Stage5 Micro Agent`, `role=validator`, `summary=Stage5 generated micro agent`, `--allow-runtime-writes` | Create first-pass micro-agent artifact | Created JSON artifact under generated micro-agents tree | PASS | Direct CLI bridge execution confirmed |

## Additional fixed defects during direct execution validation

### Defect 6 � plugin validation contract mismatched real compiler output
Observed during direct compile execution.

Cause:
- plugin expected guessed fields like `activeSleeve` and top-level `stacks`
- real compiler emits top-level `runtime` and `trace`

Fix applied:
- patched validation logic to follow the real compiler output contract
- patched promotion logic to write active state from `compiled.runtime` and `compiled.trace`

Status:
- fixed

### Defect 7 � CLI bridge lacked a direct mutation-enable path
Observed during mutation-tool validation.

Cause:
- CLI bridge was not receiving plugin config injection for `allowRuntimeWrites`
- host fallback config loader did not surface the expected plugin config in runtime

Fix applied:
- added explicit `--allow-runtime-writes` bridge flag for mutation-side CLI validation commands

Status:
- fixed for validation bridge use

## Updated release recommendation
**READY_FOR_PRIVATE_RC**

Reasoning update:
- plugin installs and loads successfully in OpenClaw
- host recognizes full tool surface
- safe-order smoke matrix executed successfully
- mutation smoke matrix executed successfully
- direct runtime defects were found and fixed under real execution pressure
- remaining risk is mainly polish/packaging refinement, not core runtime viability
