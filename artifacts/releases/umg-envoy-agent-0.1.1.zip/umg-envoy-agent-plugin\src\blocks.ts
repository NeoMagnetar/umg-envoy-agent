import { readJsonFile } from "./fs-utils.js";
import type { ResolvedPaths } from "./types.js";

export function readBlockCategoryIndex(paths: ResolvedPaths): unknown {
  return readJsonFile<unknown>(paths.blockCategoryIndexPath);
}

export function readBlockLibraryIndex(paths: ResolvedPaths): unknown {
  return readJsonFile<unknown>(paths.blockLibraryIndexPath);
}
