import fs from "node:fs";
import { Type } from "@sinclair/typebox";
import {
  createMoltBlock,
  createNeoBlock,
  createNeoStack,
  createSleeve,
  validateArtifact
} from "./authoring.js";
import { readBlockCategoryIndex, readBlockLibraryIndex } from "./blocks.js";
import { resolvePaths } from "./paths.js";
import { listRuntimeBackups, rollbackRuntimeFromBackup } from "./rollback.js";
import {
  compareSleeves,
  compileSleeveById,
  listSleeves,
  previewPromotion,
  promoteCompiledRuntime,
  summarizeActiveRuntime,
  validateCompiledRuntime
} from "./runtime.js";
import { scaffoldMicroAgentBlock } from "./scaffold.js";
import type { PluginConfig } from "./types.js";

function loadHostPluginConfigFallback(): PluginConfig {
  try {
    const configPath = "C:\\Users\\Magne\\.openclaw\\openclaw.json";
    const raw = fs.readFileSync(configPath, "utf8");
    const parsed = JSON.parse(raw);
    return parsed?.plugins?.entries?.["umg-envoy-agent"]?.config ?? {};
  } catch {
    return {};
  }
}

function effectiveConfig(config?: PluginConfig, overrides?: Partial<PluginConfig>): PluginConfig {
  return { ...loadHostPluginConfigFallback(), ...(config ?? {}), ...(overrides ?? {}) };
}

function registerCliBridge(api: any, config?: PluginConfig) {
  api.registerCli(
    ({ program }: { program: any }) => {
      const root = program.command("umg-envoy").description("UMG Envoy Agent validation and runtime utilities");

      root.command("status").action(async () => {
        const cfg = effectiveConfig(config);
        const paths = resolvePaths(cfg);
        console.log(JSON.stringify({
          stage: "stage-5-validation",
          doctrineAnchor: paths.doctrineAnchor,
          compilerRoot: paths.compilerV0Root,
          resleeverRoot: paths.resleeverRoot,
          allowRuntimeWrites: Boolean(cfg.allowRuntimeWrites),
          configSource: {
            injectedConfigPresent: Boolean(config),
            effectiveConfig: cfg
          }
        }, null, 2));
      });

      root.command("list-sleeves").action(async () => {
        const cfg = effectiveConfig(config);
        const paths = resolvePaths(cfg);
        console.log(JSON.stringify(listSleeves(paths), null, 2));
      });

      root.command("read-active-runtime").action(async () => {
        const cfg = effectiveConfig(config);
        const paths = resolvePaths(cfg);
        console.log(JSON.stringify(summarizeActiveRuntime(paths), null, 2));
      });

      root.command("list-block-libraries").action(async () => {
        const cfg = effectiveConfig(config);
        const paths = resolvePaths(cfg);
        console.log(JSON.stringify({
          categoryIndex: readBlockCategoryIndex(paths),
          libraryIndex: readBlockLibraryIndex(paths)
        }, null, 2));
      });

      root.command("compare-sleeves")
        .requiredOption("--left <id>")
        .requiredOption("--right <id>")
        .action(async (opts: { left: string; right: string }) => {
          const cfg = effectiveConfig(config);
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(compareSleeves(paths, opts.left, opts.right), null, 2));
        });

      root.command("compile-sleeve")
        .requiredOption("--sleeve <id>")
        .option("--pretty")
        .action(async (opts: { sleeve: string; pretty?: boolean }) => {
          const cfg = effectiveConfig(config);
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(await compileSleeveById(paths, opts.sleeve, { pretty: opts.pretty }), null, 2));
        });

      root.command("validate-runtime-output")
        .requiredOption("--path <file>")
        .action(async (opts: { path: string }) => {
          const fs = await import("node:fs");
          const payload = JSON.parse(fs.readFileSync(opts.path, "utf8"));
          console.log(JSON.stringify(validateCompiledRuntime(payload), null, 2));
        });

      root.command("preview-promotion")
        .requiredOption("--path <file>")
        .requiredOption("--sleeve <id>")
        .option("--label <label>")
        .action(async (opts: { path: string; sleeve: string; label?: string }) => {
          const cfg = effectiveConfig(config);
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(previewPromotion(paths, opts.path, opts.sleeve, opts.label), null, 2));
        });

      root.command("promote-runtime")
        .requiredOption("--path <file>")
        .requiredOption("--sleeve <id>")
        .option("--label <label>")
        .option("--allow-runtime-writes")
        .action(async (opts: { path: string; sleeve: string; label?: string; allowRuntimeWrites?: boolean }) => {
          const cfg = effectiveConfig(config, { allowRuntimeWrites: Boolean(opts.allowRuntimeWrites) || undefined });
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(promoteCompiledRuntime(paths, cfg, opts.path, opts.sleeve, opts.label), null, 2));
        });

      root.command("list-runtime-backups").action(async () => {
        const cfg = effectiveConfig(config);
        const paths = resolvePaths(cfg);
        console.log(JSON.stringify(listRuntimeBackups(paths), null, 2));
      });

      root.command("rollback-runtime")
        .requiredOption("--backup <dir>")
        .option("--allow-runtime-writes")
        .action(async (opts: { backup: string; allowRuntimeWrites?: boolean }) => {
          const cfg = effectiveConfig(config, { allowRuntimeWrites: Boolean(opts.allowRuntimeWrites) || undefined });
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(rollbackRuntimeFromBackup(paths, cfg, opts.backup), null, 2));
        });

      root.command("create-molt-block")
        .requiredOption("--id <id>")
        .requiredOption("--title <title>")
        .requiredOption("--molt-type <type>")
        .requiredOption("--summary <summary>")
        .option("--allow-runtime-writes")
        .action(async (opts: { id: string; title: string; moltType: string; summary: string; allowRuntimeWrites?: boolean }) => {
          const cfg = effectiveConfig(config, { allowRuntimeWrites: Boolean(opts.allowRuntimeWrites) || undefined });
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(createMoltBlock(paths, cfg, {
            id: opts.id,
            title: opts.title,
            moltType: opts.moltType,
            summary: opts.summary
          }), null, 2));
        });

      root.command("create-neoblock")
        .requiredOption("--id <id>")
        .requiredOption("--title <title>")
        .requiredOption("--summary <summary>")
        .option("--allow-runtime-writes")
        .action(async (opts: { id: string; title: string; summary: string; allowRuntimeWrites?: boolean }) => {
          const cfg = effectiveConfig(config, { allowRuntimeWrites: Boolean(opts.allowRuntimeWrites) || undefined });
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(createNeoBlock(paths, cfg, opts), null, 2));
        });

      root.command("create-neostack")
        .requiredOption("--id <id>")
        .requiredOption("--title <title>")
        .requiredOption("--summary <summary>")
        .option("--allow-runtime-writes")
        .action(async (opts: { id: string; title: string; summary: string; allowRuntimeWrites?: boolean }) => {
          const cfg = effectiveConfig(config, { allowRuntimeWrites: Boolean(opts.allowRuntimeWrites) || undefined });
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(createNeoStack(paths, cfg, opts), null, 2));
        });

      root.command("create-sleeve")
        .requiredOption("--id <id>")
        .requiredOption("--title <title>")
        .requiredOption("--stack <id...>")
        .option("--allow-runtime-writes")
        .action(async (opts: { id: string; title: string; stack: string[]; allowRuntimeWrites?: boolean }) => {
          const cfg = effectiveConfig(config, { allowRuntimeWrites: Boolean(opts.allowRuntimeWrites) || undefined });
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(createSleeve(paths, cfg, {
            id: opts.id,
            title: opts.title,
            stackIds: opts.stack
          }), null, 2));
        });

      root.command("validate-artifact")
        .requiredOption("--kind <kind>")
        .requiredOption("--path <file>")
        .action(async (opts: { kind: string; path: string }) => {
          const fs = await import("node:fs");
          const payload = JSON.parse(fs.readFileSync(opts.path, "utf8"));
          console.log(JSON.stringify(validateArtifact(payload, opts.kind), null, 2));
        });

      root.command("scaffold-micro-agent")
        .requiredOption("--id <id>")
        .requiredOption("--title <title>")
        .requiredOption("--role <role>")
        .requiredOption("--summary <summary>")
        .option("--allow-runtime-writes")
        .action(async (opts: { id: string; title: string; role: string; summary: string; allowRuntimeWrites?: boolean }) => {
          const cfg = effectiveConfig(config, { allowRuntimeWrites: Boolean(opts.allowRuntimeWrites) || undefined });
          const paths = resolvePaths(cfg);
          console.log(JSON.stringify(scaffoldMicroAgentBlock(paths, cfg, opts), null, 2));
        });
    },
    { commands: ["umg-envoy"] }
  );
}

const entry = {
  id: "umg-envoy-agent",
  name: "UMG Envoy Agent",
  description:
    "UMG cognitive runtime plugin that bridges doctrine, canonical compiler, and resleever operations.",
  register(api: { registerTool: (definition: any, options?: { optional?: boolean }) => void; registerCli?: (register: any, options?: { commands?: string[] }) => void }, config?: PluginConfig) {
    registerCliBridge(api, config);

    api.registerTool(
      {
        name: "umg_envoy_status",
        description:
          "Report plugin integration status, resolved paths, and current implementation stage.",
        parameters: Type.Object({}, { additionalProperties: false }),
        async execute() {
          const paths = resolvePaths(config ?? {});

          return {
            content: [
              {
                type: "text",
                text:
                  [
                    "UMG Envoy Agent status:",
                    "- Stage 1 complete: plugin scaffold established.",
                    "- Stage 2 complete: doctrine anchor, compiler vendor tree, and resleever vendor tree integrated.",
                    "- Stage 3 active: runtime helpers and OpenClaw tool registrations are present.",
                    `- Doctrine anchor: ${paths.doctrineAnchor}`,
                    `- Compiler root: ${paths.compilerV0Root}`,
                    `- Resleever root: ${paths.resleeverRoot}`,
                    `- Runtime writes enabled: ${Boolean(config?.allowRuntimeWrites)}`
                  ].join("\n")
              }
            ]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_list_sleeves",
        description: "List sleeves from the resleever sleeve catalog and resolve their source file paths.",
        parameters: Type.Object({}, { additionalProperties: false }),
        async execute() {
          const paths = resolvePaths(config ?? {});
          const sleeves = listSleeves(paths);

          return {
            content: [{ type: "text", text: JSON.stringify(sleeves, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_read_active_runtime",
        description: "Read active sleeve and stack runtime state from the resleever runtime directory.",
        parameters: Type.Object({}, { additionalProperties: false }),
        async execute() {
          const paths = resolvePaths(config ?? {});
          const summary = summarizeActiveRuntime(paths);

          return {
            content: [{ type: "text", text: JSON.stringify(summary, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_compare_sleeves",
        description: "Compare two sleeves and return mode and stack-level differences.",
        parameters: Type.Object(
          {
            leftSleeveId: Type.String(),
            rightSleeveId: Type.String()
          },
          { additionalProperties: false }
        ),
        async execute(_id: string, params: { leftSleeveId: string; rightSleeveId: string }) {
          const paths = resolvePaths(config ?? {});
          const result = compareSleeves(paths, params.leftSleeveId, params.rightSleeveId);

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_list_block_libraries",
        description: "Read bundled or overridden block category and MOLT library index files.",
        parameters: Type.Object({}, { additionalProperties: false }),
        async execute() {
          const paths = resolvePaths(config ?? {});
          const categoryIndex = readBlockCategoryIndex(paths);
          const libraryIndex = readBlockLibraryIndex(paths);

          return {
            content: [{ type: "text", text: JSON.stringify({ categoryIndex, libraryIndex }, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_compile_sleeve",
        description: "Compile a sleeve by id through the canonical UMG compiler and return the resulting runtime output path.",
        parameters: Type.Object(
          {
            sleeveId: Type.String({ description: "Sleeve id from the sleeve catalog." }),
            pretty: Type.Optional(Type.Boolean({ description: "Pretty-print compiler output JSON." }))
          },
          { additionalProperties: false }
        ),
        async execute(_id: string, params: { sleeveId: string; pretty?: boolean }) {
          const paths = resolvePaths(config ?? {});
          const result = await compileSleeveById(paths, params.sleeveId, { pretty: params.pretty });

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_validate_runtime_output",
        description: "Validate a compiled runtime JSON output before promotion or downstream use.",
        parameters: Type.Object(
          {
            compiledOutputPath: Type.String({ description: "Path to the compiled runtime JSON output." })
          },
          { additionalProperties: false }
        ),
        async execute(_id: string, params: { compiledOutputPath: string }) {
          const compiled = await import("node:fs").then(({ readFileSync }) =>
            JSON.parse(readFileSync(params.compiledOutputPath, "utf8"))
          );
          const validation = validateCompiledRuntime(compiled);

          return {
            content: [{ type: "text", text: JSON.stringify(validation, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_preview_promotion",
        description: "Preview a runtime promotion and return the expected active-state changes without writing runtime files.",
        parameters: Type.Object(
          {
            compiledOutputPath: Type.String({ description: "Path to the compiled runtime JSON output." }),
            sleeveId: Type.String({ description: "Sleeve id being promoted." }),
            promotionLabel: Type.Optional(Type.String({ description: "Optional human label for this promotion." }))
          },
          { additionalProperties: false }
        ),
        async execute(
          _id: string,
          params: { compiledOutputPath: string; sleeveId: string; promotionLabel?: string }
        ) {
          const paths = resolvePaths(config ?? {});
          const preview = previewPromotion(paths, params.compiledOutputPath, params.sleeveId, params.promotionLabel);

          return {
            content: [{ type: "text", text: JSON.stringify(preview, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_promote_runtime",
        description: "Promote a compiled runtime output into active resleever state with validation and backup. Requires allowRuntimeWrites.",
        parameters: Type.Object(
          {
            compiledOutputPath: Type.String({ description: "Path to the compiled runtime JSON output." }),
            sleeveId: Type.String({ description: "Sleeve id being promoted." }),
            promotionLabel: Type.Optional(Type.String({ description: "Optional human label for this promotion." }))
          },
          { additionalProperties: false }
        ),
        async execute(
          _id: string,
          params: { compiledOutputPath: string; sleeveId: string; promotionLabel?: string }
        ) {
          const paths = resolvePaths(config ?? {});
          const result = promoteCompiledRuntime(paths, config ?? {}, params.compiledOutputPath, params.sleeveId, params.promotionLabel);

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_list_runtime_backups",
        description: "List available runtime backup snapshots created before promotions.",
        parameters: Type.Object({}, { additionalProperties: false }),
        async execute() {
          const paths = resolvePaths(config ?? {});
          const backups = listRuntimeBackups(paths);

          return {
            content: [{ type: "text", text: JSON.stringify(backups, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_rollback_runtime",
        description: "Restore active runtime files from a previous backup snapshot. Requires allowRuntimeWrites.",
        parameters: Type.Object(
          {
            backupDir: Type.String({ description: "Path to a runtime backup directory." })
          },
          { additionalProperties: false }
        ),
        async execute(_id: string, params: { backupDir: string }) {
          const paths = resolvePaths(config ?? {});
          const result = rollbackRuntimeFromBackup(paths, config ?? {}, params.backupDir);

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_create_molt_block",
        description: "Create a structured MOLT block artifact. Requires allowRuntimeWrites.",
        parameters: Type.Object(
          {
            id: Type.String(),
            title: Type.String(),
            moltType: Type.String(),
            summary: Type.String(),
            authority: Type.Optional(Type.Number()),
            tags: Type.Optional(Type.Array(Type.String())),
            targetFolder: Type.Optional(Type.String())
          },
          { additionalProperties: false }
        ),
        async execute(
          _id: string,
          params: {
            id: string;
            title: string;
            moltType: string;
            summary: string;
            authority?: number;
            tags?: string[];
            targetFolder?: string;
          }
        ) {
          const paths = resolvePaths(config ?? {});
          const result = createMoltBlock(paths, config ?? {}, params);

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_create_neoblock",
        description: "Create a structured NeoBlock artifact. Requires allowRuntimeWrites.",
        parameters: Type.Object(
          {
            id: Type.String(),
            title: Type.String(),
            summary: Type.String(),
            blockIds: Type.Optional(Type.Array(Type.String())),
            targetFolder: Type.Optional(Type.String())
          },
          { additionalProperties: false }
        ),
        async execute(
          _id: string,
          params: {
            id: string;
            title: string;
            summary: string;
            blockIds?: string[];
            targetFolder?: string;
          }
        ) {
          const paths = resolvePaths(config ?? {});
          const result = createNeoBlock(paths, config ?? {}, params);

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_create_neostack",
        description: "Create a structured NeoStack artifact. Requires allowRuntimeWrites.",
        parameters: Type.Object(
          {
            id: Type.String(),
            title: Type.String(),
            summary: Type.String(),
            memberIds: Type.Optional(Type.Array(Type.String())),
            targetFolder: Type.Optional(Type.String())
          },
          { additionalProperties: false }
        ),
        async execute(
          _id: string,
          params: {
            id: string;
            title: string;
            summary: string;
            memberIds?: string[];
            targetFolder?: string;
          }
        ) {
          const paths = resolvePaths(config ?? {});
          const result = createNeoStack(paths, config ?? {}, params);

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_create_sleeve",
        description: "Create a structured Sleeve artifact. Requires allowRuntimeWrites.",
        parameters: Type.Object(
          {
            id: Type.String(),
            title: Type.String(),
            stackIds: Type.Array(Type.String()),
            mode: Type.Optional(Type.String()),
            bpMode: Type.Optional(Type.String()),
            notes: Type.Optional(Type.String()),
            targetFolder: Type.Optional(Type.String())
          },
          { additionalProperties: false }
        ),
        async execute(
          _id: string,
          params: {
            id: string;
            title: string;
            stackIds: string[];
            mode?: string;
            bpMode?: string;
            notes?: string;
            targetFolder?: string;
          }
        ) {
          const paths = resolvePaths(config ?? {});
          const result = createSleeve(paths, config ?? {}, params);

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_validate_artifact",
        description: "Validate a UMG artifact payload as a MOLT block, NeoBlock, NeoStack, or Sleeve.",
        parameters: Type.Object(
          {
            kind: Type.String(),
            payload: Type.Any()
          },
          { additionalProperties: false }
        ),
        async execute(_id: string, params: { kind: string; payload: unknown }) {
          const result = validateArtifact(params.payload, params.kind);

          return {
            content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
          };
        }
      },
      { optional: true }
    );

    api.registerTool(
      {
        name: "umg_envoy_scaffold_micro_agent",
        description: "Create a first-pass micro-agent block scaffold in the resleever block tree. Requires allowRuntimeWrites.",
        parameters: Type.Object(
          {
            id: Type.String(),
            title: Type.String(),
            role: Type.String(),
            summary: Type.String(),
            targetFolder: Type.Optional(Type.String())
          },
          { additionalProperties: false }
        ),
        async execute(
          _id: string,
          params: {
            id: string;
            title: string;
            role: string;
            summary: string;
            targetFolder?: string;
          }
        ) {
          const paths = resolvePaths(config ?? {});
          const result = scaffoldMicroAgentBlock(paths, config ?? {}, params);

          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(result, null, 2)
              }
            ]
          };
        }
      },
      { optional: true }
    );
  }
};

export default entry;
