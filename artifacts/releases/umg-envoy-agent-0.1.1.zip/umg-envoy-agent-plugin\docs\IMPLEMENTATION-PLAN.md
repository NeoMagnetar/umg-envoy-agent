# UMG Envoy Agent — Implementation Plan

## Goal
Build a true native OpenClaw plugin named **UMG Envoy Agent** that exposes UMG doctrine, compiler, sleeve runtime, and resleeving operations through explicit OpenClaw tools.

## Stage breakdown

### Stage 1 — Discovery + plugin scaffold
Deliverables:
- plugin root structure
- `package.json`
- `openclaw.plugin.json`
- `README.md`
- implementation plan
- doctrine anchor identification

Status: complete

### Stage 2 — Source integration
Deliverables:
- vendor or copy doctrine anchor docs into plugin `spec/`
- vendor the canonical `umg-compiler` buildable source
- vendor the `UMG_Envoy_Resleever` runtime homebase materials needed for local plugin behavior
- add notes describing override-path behavior versus bundled defaults

### Stage 3 — Runtime helpers + tool registration
Deliverables:
- plugin entrypoint
- path resolution helpers
- compiler invocation helper
- sleeve/block inspection helpers
- runtime promotion / resleeve helper
- initial OpenClaw tool set

### Stage 4 — Validation + packaging docs
Deliverables:
- local build validation
- review notes / risk notes
- publish/package instructions
- critique file and next-pass engineering notes

## Architectural stance
- Use the revamp workspace as doctrine/reference, not as runtime execution code.
- Use the real compiler as compiler, not a fake replacement.
- Use the resleever as runtime state manager, not as doctrinal canon.
- Keep runtime writes gated by explicit config and optional tool registration where appropriate.
- Favor conservative first-pass tools that are inspectable and auditable.

## Expected first-pass tools
- `umg_envoy_status`
- `umg_envoy_list_sleeves`
- `umg_envoy_read_active_runtime`
- `umg_envoy_compile_sleeve`
- `umg_envoy_promote_runtime`
- `umg_envoy_list_block_libraries`
- `umg_envoy_scaffold_micro_agent`

## Constraints observed during intake
- The globally installed ClawHub CLI is currently `v0.9.0`, even though a newer local plugin-packager artifact exists in extracted files.
- The local extracted packager reference is being treated as packaging/template guidance, not as proof that the globally installed CLI has identical behavior.
- A missing zip path originally supplied by the user was later resolved indirectly via extracted contents under `UMG_Revamp_Workspace\UNZIPPED FILES`.
