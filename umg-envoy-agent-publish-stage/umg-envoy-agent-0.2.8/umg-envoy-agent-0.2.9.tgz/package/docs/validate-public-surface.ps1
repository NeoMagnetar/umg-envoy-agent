$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$failures = @()

function Check-PathAbsent($path) {
  if (Test-Path $path) { $script:failures += "Unexpected path present: $path" }
}

function Check-StringAbsent($path, $pattern) {
  if (Test-Path $path) {
    $matches = Select-String -Path $path -Pattern $pattern -SimpleMatch -ErrorAction SilentlyContinue
    if ($matches) { $script:failures += "Unexpected string '$pattern' found in $path" }
  }
}

Check-PathAbsent (Join-Path $root 'dist/compiler/compiler-process.js')
Check-PathAbsent (Join-Path $root 'dist/compiler/compiler-process.d.ts')
Check-PathAbsent (Join-Path $root 'dist/compiler/compiler-bridge.js')
Check-PathAbsent (Join-Path $root 'dist/compiler/compiler-bridge.d.ts')
Check-PathAbsent (Join-Path $root 'dist/compiler/relation-matrix-emitter.js')
Check-PathAbsent (Join-Path $root 'dist/compiler/relation-matrix-emitter.d.ts')

Get-ChildItem -Path (Join-Path $root 'dist') -Recurse -File | ForEach-Object {
  Check-StringAbsent $_.FullName 'node:child_process'
  Check-StringAbsent $_.FullName 'spawn('
  Check-StringAbsent $_.FullName 'umg_envoy_compile_ir_bridge'
  Check-StringAbsent $_.FullName 'compile-ir-bridge'
  Check-StringAbsent $_.FullName 'umg_envoy_emit_relation_matrix'
  Check-StringAbsent $_.FullName 'emit-relation-matrix'
}

Check-StringAbsent (Join-Path $root 'openclaw.plugin.json') 'umg_envoy_compile_ir_bridge'
Check-StringAbsent (Join-Path $root 'openclaw.plugin.json') 'umg_envoy_emit_relation_matrix'

if ($failures.Count -gt 0) {
  $failures | ForEach-Object { Write-Error $_ }
  exit 1
}

Write-Output 'PUBLIC_SURFACE_OK'
